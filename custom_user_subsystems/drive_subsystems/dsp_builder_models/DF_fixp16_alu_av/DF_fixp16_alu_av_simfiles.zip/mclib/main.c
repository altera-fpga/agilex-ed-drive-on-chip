#include "main.h"
#include <stdio.h>
#ifdef MATLAB_MEX_FILE
#include "simstruc.h"
#endif
#ifndef MATLAB_MEX_FILE
#include "includes.h"
#define SPEED_SHIFT_INT 0
//#define LOOPBACK
#define OFFSET_ACCUM_ISR_COUNT  256
#define CURRENT_OFFSET_LIMIT    400
static drive_params dp[4]; // DRIVE_SECTION;
static int axis_select = 0;
static int latency = 0;
static calc_type_e enable_dspba = SOFT_FIXP;
static short dc_link_voltage = 0 ;            // DC Link Value
static short dc_link_current = 0 ;
static int runtime =   0 ;
static int cnt_IRQ =   0 ;
void *virtual_base;
unsigned int irq_counter = 0;
int dn; // drive number index
int restart_drive = 0;
int counter = 0;
struct timeval start, end;
long secs_used,micros_used;
#endif


//################################################################################################
//DC Link Voltage Error
//###################################################################################################
static void dc_link_voltage_check(void){
    
#ifndef MATLAB_MEX_FILE
    dc_link_read(&dc_link_voltage, &dc_link_current);
    int dcl_status = IORD_16DIRECT(DOC_DC_LINK_BASE, DOC_DC_LINK_STATUS) ;
    debug_printf(DBG_INFO, "---> DC_Link Voltage Check : Undervoltage limit = %i V  Overvoltage limit = %i V  \n", platform.powerboard->undervoltage, platform.powerboard->overvoltage);
    
    
    while ((dcl_status != 0) || (dc_link_voltage < platform.powerboard->undervoltage)) {
        // Wait 1 second
        //OSTimeDlyHMSM(0, 0, 1, 0);
        OSTimeDlyHMSM(0, 0, 0, 500);
        dc_link_read(&dc_link_voltage, &dc_link_current);
        dcl_status = IORD_16DIRECT(DOC_DC_LINK_BASE, DOC_DC_LINK_STATUS);
        
        if ((dcl_status != 0) || (dc_link_voltage < platform.powerboard->undervoltage)) {
            debug_printf(DBG_ERROR, "---> DC Link Error = %s %s %i V\n",
                    dcl_status & DOC_DC_LINK_STATUS_OV_BIT?"Overvoltage" : "",
                            dcl_status & DOC_DC_LINK_STATUS_UV_BIT?"Undervoltage" : "",
                                    dc_link_voltage);
        }
        
        if (platform.powerboard->sysid == SYSID_PB_ALT12_MULTIAXIS) {
            // Altera power board has DC link current sense
            debug_printf(DBG_INFO, "--->             : %i  mA \n",dc_link_current);
        }
        debug_printf(DBG_WARN, "---> Check power connection. \n");
    }
    //OSTimeDlyHMSM(0, 0, 1, 0);
    OSTimeDlyHMSM(0, 0, 0, 500);
    debug_printf(DBG_INFO, "DC_Link : %i  V - PASSED\n", dc_link_voltage);
    //Note that if the power board is not powered at all the ADCs are not powered and the reading here is invalid.
    //An error will be detected in the ADC calibration routine as no clocks are received from the ADCs.
#endif
}


/**
 * Helper function to print diagnostics based on error state. Called from main loop.
 *
 * @param dn
 */
static void decode_error_state(int dn) {
#ifndef MATLAB_MEX_FILE
    
	int error = 0;

	int state = ((0x0FFF & IORD_16DIRECT(dp[dn].DOC_SM_BASE_ADDR, SM_STATUS))) >> 9;
	
	if (state == 4) {
		debug_printf(DBG_ERROR, "Axis %d: Actual State is Error!\n", dn);
		if (dp[dn].status_word & STATUS_REG_ERR_OC) {
			debug_printf(DBG_ERROR, "--> Axis %d: ERROR: <Overcurrent>\n", dn);
			debug_printf(DBG_ERROR,
					"Axis %d: I_U:%d\t\tI_W:%d\t\t\n",
					dn,
					(short) IORD_16DIRECT(dp[dn].DOC_ADC_BASE_ADDR,
							OC_CAPTURE_U),
					(short) IORD_16DIRECT(dp[dn].DOC_ADC_BASE_ADDR,OC_CAPTURE_W));
			debug_printf(DBG_ERROR, "Axis %d: I_Ref:%d\n", (short) dn,
					IORD_16DIRECT(dp[dn].DOC_ADC_BASE_ADDR,ADC_I_PEAK));

			error = 1;
		}
		if (dp[dn].status_word & STATUS_REG_ERR_OV) {
			debug_printf(DBG_ERROR, "Axis %d: --> ERROR: <Overvoltage>\n", dn);
			dc_link_read(&dc_link_voltage, &dc_link_current);
			debug_printf(DBG_ERROR, "U_DC_LINK: %i Volt \n", dc_link_voltage);
			// Altera power board has DC link current sense
			debug_printf(DBG_ERROR, "--->         : %i mA\n", dc_link_current);
			error = 1;
		}
		if (dp[dn].status_word & STATUS_REG_ERR_UV) {
			debug_printf(DBG_ERROR, "Axis %d: --> ERROR: <DC-Link-Error>\n",
					dn);
			dc_link_read(&dc_link_voltage, &dc_link_current);
			debug_printf(DBG_ERROR, "U_DC_LINK: %i Volt \n", dc_link_voltage);
			if (platform.powerboard->sysid == SYSID_PB_ALT12_MULTIAXIS) {
				// Altera power board has DC link current sense
				debug_printf(DBG_ERROR, "--->         : %i mA\n",dc_link_current);
			}
			error = 1;
		}
		if (dp[dn].status_word & STATUS_REG_ERR_CLOCK) {
			debug_printf(DBG_ERROR,
					"Axis %d: --> ERROR: <SD-Clock or DC-Link-Clock-Error>\n",
					dn);
			error = 1;
		}
		if (dp[dn].status_word & STATUS_REG_ERR_IGBT) {
			debug_printf(DBG_ERROR,
					"Axis %d: --> ERROR: <IGBT-Error (no voltage?)>\n", dn);
			error = 1;
		}
		if (dp[dn].status_word & STATUS_REG_ERR_CHOPPER) {
			debug_printf(DBG_ERROR, "Axis %d: --> ERROR: <Chopper>\n", dn);
		}
		if (error == 0) {
			debug_printf(DBG_ERROR, "Axis %d: --> ERROR: <Unknown> %d\n", dn,
					dp[dn].status_word);
		}
	} else {
		debug_printf(DBG_INFO, "Axis %d: --> No Error\n", dn);
	}
#endif
}


/**
 * Helper function called for each axis from motor task to initialize drive data structure.
 *
 * @param dn	drive axis to be initialized
 */
static void	init_axis(
        int dn, 
        int Current_Kp, 
        int Current_Ki, 
        int Current_PI_Limit, 
        int I_Limit, 
        int Speed_Kp, 
        int Speed_Ki,
        int Speed_PI_Limit
        ) {
    
#ifndef MATLAB_MEX_FILE
    //init_debug(dn, &dp[0]);
    
    //---------------------------------------------------------------------------------------------------------------------
    // Init PI controllers DSP
    //---------------------------------------------------------------------------------------------------------------------
    dp[dn].Id_PI.Kp = Current_Kp;
    dp[dn].Id_PI.Ki = Current_Ki;
    dp[dn].Id_PI.input_frac_bits = 10;
    dp[dn].Id_PI.feedback_limit = Current_PI_Limit;
    dp[dn].Id_PI.integrator_limit = I_Limit;
    dp[dn].Id_PI.output_limit = I_Limit;
    PI_reset_q15(&dp[dn].Id_PI);
    
    dp[dn].Iq_PI.Kp = Current_Kp;
    dp[dn].Iq_PI.Ki = Current_Ki;
    dp[dn].Iq_PI.input_frac_bits = 10;
    dp[dn].Iq_PI.feedback_limit = Current_PI_Limit;
    dp[dn].Iq_PI.integrator_limit = I_Limit;
    dp[dn].Iq_PI.output_limit = I_Limit;
    PI_reset_q15(&dp[dn].Iq_PI);
    
#ifndef __NIOS__
    dp[dn].Id_PI_f.Kp = ((float)dp[dn].Id_Kp) *  SHIFTR10FLOAT;
    dp[dn].Id_PI_f.Ki = ((float)dp[dn].Id_Ki) * SHIFTR10FLOAT;
    dp[dn].Id_PI_f.feedback_limit = ((float)dp[dn].I_sat_limit) * SHIFTR10FLOAT;
    dp[dn].Id_PI_f.integrator_limit = ((float)dp[dn].V_sat_limit) * SHIFTR10FLOAT;
    dp[dn].Id_PI_f.output_limit = ((float)dp[dn].V_sat_limit) * SHIFTR10FLOAT;
    PI_reset_f(&dp[dn].Id_PI_f);
    
    dp[dn].Iq_PI_f.Kp = ((float)dp[dn].Iq_Kp) * SHIFTR10FLOAT;
    dp[dn].Iq_PI_f.Ki = ((float)dp[dn].Iq_Ki) * SHIFTR10FLOAT;
    dp[dn].Iq_PI_f.feedback_limit = ((float)dp[dn].I_sat_limit) * SHIFTR10FLOAT;
    dp[dn].Iq_PI_f.integrator_limit = ((float)dp[dn].V_sat_limit) * SHIFTR10FLOAT;
    dp[dn].Iq_PI_f.output_limit = ((float)dp[dn].V_sat_limit) * SHIFTR10FLOAT;
    PI_reset_f(&dp[dn].Iq_PI_f);
#endif
    
    dp[dn].Speed_PI.Kp = Speed_Kp;
    dp[dn].Speed_PI.Ki = Speed_Ki;
    dp[dn].Speed_PI.input_frac_bits = 12 + SPEED_FRAC_BITS;
    dp[dn].Speed_PI.feedback_limit = Speed_PI_Limit;
    dp[dn].Speed_PI.integrator_limit = I_Limit;
    dp[dn].Speed_PI.output_limit = I_Limit;
    PI_reset_q15(&dp[dn].Speed_PI);
    
    dp[dn].Position_PI.Kp = dp[dn].pos_Kp;
    dp[dn].Position_PI.Ki = dp[dn].pos_spdff_Kp;
    dp[dn].Position_PI.input_frac_bits = 10 - SPEED_FRAC_BITS; //17;
    
    dp[dn].Position_PI.integrator_limit = 0;
    dp[dn].Position_PI.feedback_limit = 1073741824; //32000; //Max short_int
    
    dp[dn].Position_PI.output_limit = dp[dn].pos_limit;
    PI_reset_q15(&dp[dn].Position_PI);
    
#ifndef __NIOS__
    initWaveform(&dp[dn].cmd_wave_struct);
    dp[dn].cmd_wave_struct.Period_int32=dp[dn].cmd_wave_period; // Waveform period in 16kHz samples
    dp[dn].cmd_wave_struct.Offset_int32= dp[dn].cmd_wave_offset; // Waveform offset in 16kHz samples
    //dp[dn].cmd_wave_struct.Amp_ND_f=dp[dn].cmd_wave_amp_spd_rpm_f;   // Waveform amplitude, non-dimensional (to be multiplied by fullscale and units)
    dp[dn].cmd_wave_struct.Shape_enum=dp[dn].cmd_wave_type;    // Waveform type.
    
    initNotch(&dp[dn].filt_struct_temp,0.0);
    //Setup filter input parameters before calling calcNotchCoeffs
    dp[dn].filt_struct_temp.Fn_Hz_f = dp[dn].filt_fn_hz_f;
    dp[dn].filt_struct_temp.Fd_Hz_f = dp[dn].filt_fd_hz_f;
    dp[dn].filt_struct_temp.zetan_ND_f = dp[dn].filt_zn_f;
    dp[dn].filt_struct_temp.zetad_ND_f = dp[dn].filt_zd_f;
    dp[dn].filt_struct_temp.dc_gain_f = 1.0;
    dp[dn].filt_struct_temp.T_s_f = 62.5e-06;
    
    calcNotchCoeffs(&dp[dn].filt_struct_temp);
#endif
    
    //---------------------------------------------------------------------------------------------------------------------
    // Init DSP Builder subsystems
    //---------------------------------------------------------------------------------------------------------------------
    debug_printf(DBG_INFO, "Init DSP Builder subsystems\n");
    
#ifdef __NIOS__
    //INIT_DSPBA_DOC_Single_Axis_dspba_fixp_regs (FOC_FIXED_POINT_BASE, dp[dn].I_sat_limit, dp[dn].Id_Ki,
    //											dp[dn].Id_Kp, dp[dn].V_sat_limit, dn);
#else
    IOWR_32DIRECT(DSPBA_FILT_FIXP_BASE,reset_INPUT, 1);
    IOWR_32DIRECT(DSPBA_FILT_FIXP_BASE,DSPBA_START, 1);
    IOWR_32DIRECT(DSPBA_FILT_FIXP_BASE,reset_INPUT, 0);
    
    INIT_DSPBA_DOC_Single_Axis_dspba_filt_fixp_regs (DSPBA_FILT_FIXP_BASE, dp[dn].I_sat_limit, dp[dn].Id_Ki, dp[dn].Id_Kp,
            dp[dn].V_sat_limit, dp[dn].filt_struct0.a1_f, dp[dn].filt_struct0.a2_f, dp[dn].filt_struct0.b0_f, dp[dn].filt_struct0.b1_f, dp[dn].filt_struct0.b2_f,
            (dp[dn].filt_en == 1)?0:1, dp[dn].filt_struct0.dc_gain_f,dn);
#endif
            
#ifdef __NIOS__
            //INIT_DSPBA_DOC_Single_Axis_dspba_floatp_regs (FOC_FLOATING_POINT_BASE, dp[dn].I_sat_limit, dp[dn].Id_Ki,
            //											 dp[dn].Id_Kp, dp[dn].V_sat_limit, dn);
#else
            INIT_DSPBA_DOC_Single_Axis_dspba_filt_floatp_regs (DSPBA_FILT_FLOATP_BASE, dp[dn].I_sat_limit, dp[dn].Id_Ki, dp[dn].Id_Kp,
                    dp[dn].V_sat_limit, dp[dn].filt_struct0.a1_f, dp[dn].filt_struct0.a2_f, dp[dn].filt_struct0.b0_f, dp[dn].filt_struct0.b1_f, dp[dn].filt_struct0.b2_f,
                    (dp[dn].filt_en == 1)?0:1, dp[dn].filt_struct0.dc_gain_f,dn);
#endif
#endif
}


/**
 * @brief Helper function for position control
 *
 * @param Position_PI
 * @param enc_data
 * @param enc_data_old
 * @param pos_temp
 * @param pos_int
 * @param pos_setpoint
 * @param pos_limit
 * @param speed_command
 * @param encoder_singleturn_bits
 */
 #ifndef MATLAB_MEX_FILE
static void position_control( pi_instance_q15 * Position_PI, int enc_data,  int * enc_data_old,
									 int * pos_temp,  int * pos_int, int pos_setpoint, int pos_limit,
									 int * speed_command, int encoder_singleturn_bits){

    int  delta_phi  ;
    int  shifted_enc_data = enc_data << (23-encoder_singleturn_bits);

    delta_phi = (shifted_enc_data - *enc_data_old);
    if((delta_phi) > Bit22){
        *pos_temp -= Bit23;
    }else if((delta_phi) < -Bit22){
        *pos_temp += Bit23;
    }
    *enc_data_old = shifted_enc_data;
    *pos_int      = (shifted_enc_data >> 7) + (*pos_temp >>7);

    Position_PI->feedback = *pos_int;
    Position_PI->setpoint = pos_setpoint;
    PI_control_q15(Position_PI,0);  //Direct current control
    * speed_command = (short)Position_PI->output;

}
#endif

/**
 * @brief process input data
 *
 * Helper function for ISR to process input data
 *
 * @param dp	Pointer to axis data structure
 */
#ifndef MATLAB_MEX_FILE
static void process(int mode, drive_params * dp, int Valpha, int Vbeta) {

	int dn = 0;

	for (dn = platform.first_drive; dn <= platform.last_drive; dn++) {
		// Software fixed point
		dp[dn].sin_phi_q15 = SINE(dp[dn].phi_elec);
		dp[dn].cos_phi_q15 = COSINE(dp[dn].phi_elec);
		clark_transform_q10(dp[dn].Iu, dp[dn].Iw, &dp[dn].Ialpha, &dp[dn].Ibeta) ;
		park_transformation_q10(dp[dn].Ialpha, dp[dn].Ibeta, &dp[dn].Id, &dp[dn].Iq, dp[dn].sin_phi_q15, dp[dn].cos_phi_q15) ;
		dp[dn].Id_PI.feedback = dp[dn].Id;
		dp[dn].Id_PI.setpoint = dp[dn].i_command_d;
		PI_control_q15(&dp[dn].Id_PI, ((dp[dn].enable_drive == 0)|(dp[dn].reset_control == 1)) );  //Direct current control
		dp[dn].Iq_PI.feedback = dp[dn].Iq;
		dp[dn].Iq_PI.setpoint = dp[dn].i_command_q;
		PI_control_q15(&dp[dn].Iq_PI,((dp[dn].enable_drive == 0)|(dp[dn].reset_control == 1)) );  //Quadrature current control
		dp[dn].Vd = dp[dn].Id_PI.output;
		dp[dn].Vq = dp[dn].Iq_PI.output;
		inverse_park_q10(dp[dn].Vd,dp[dn].Vq,&dp[dn].Valpha,&dp[dn].Vbeta,dp[dn].sin_phi_q15,dp[dn].cos_phi_q15) ;
			
		// Space vector modulation for outputs
        if (mode==1)
            svm(PWMMAX, dp[dn].Valpha, dp[dn].Vbeta, & dp[dn].Vu_PWM, & dp[dn].Vv_PWM, & dp[dn].Vw_PWM); //FOC in C
        else
            svm(PWMMAX, Valpha, Vbeta, & dp[dn].Vu_PWM, & dp[dn].Vv_PWM, & dp[dn].Vw_PWM); //FOC in Simulink SW or HW
		
		// Write new PWM values to hardware ready for next cycle
		if ( dp[dn].enable_drive == 1 ){
			pwm_update(dp[dn].DOC_PWM_BASE_ADDR, dp[dn].Vu_PWM, dp[dn].Vv_PWM, dp[dn].Vw_PWM);
		} else {
			// Disabled axes set stationary by setting PWM to midpoint
			pwm_update(dp[dn].DOC_PWM_BASE_ADDR, (PWMMAX+1)/2-1, (PWMMAX+1)/2-1, (PWMMAX+1)/2-1);
		}
		if (dp[dn].reset_control == 1) {
//			debug_printf(DBG_INFO, "---> Axis %d: Reset Control\n",dn);
		}
		dp[dn].reset_control = 0;
	}

}
#endif


/**
 * Restart all drives.
 *
 * Helper function called from main loop.
 */
static void	restart_all_drives(void) {
#ifndef MATLAB_MEX_FILE
	int dn;
	
	for (dn = platform.first_drive; dn <= platform.last_drive; dn++){ //MAX
	   dsm_reset(dp[dn].DOC_SM_BASE_ADDR);
	   dp[dn].enable_drive = 0 ;              // disable
	   //SPC
	   dp[dn].speed_command = 100<<SPEED_FRAC_BITS;        // set back to initial speed
#ifndef __SIMULINK__
	   debug_write_status (dn, DOC_DBG_SPEED_SETP0, dp[dn].speed_command>>SPEED_FRAC_BITS);
#endif
	}
#endif
}
/**
 * Used during startup to determine ADC zero offsets which can then be used to
 * correct ADC readings in control loop.
 *
 * @param start		set to 1 to start offset accumulation
 * @param Offset_U	U phase offset accumulator
 * @param Offset_W	W phase offset accumulator
 * @param Iu		U phase current reading
 * @param Iw		W phase current reading
 */
static void inline adc_offset_accumulate(int * start, int * Offset_U, int * Offset_W, short Iu, short Iw) {
#ifndef MATLAB_MEX_FILE
    if (*start > 0) {
        if (*start < (OFFSET_ACCUM_ISR_COUNT + 1)){
            *Offset_U +=  Iu ;
            *Offset_W +=  Iw ;
            (*start)++;
        } else {
            *start = 0;
        }
    }
#endif
}

//################################################################################################
//ADC IRQ Check & Offset Current Calculation
//################################################################################################
// Read current values in idle state and average over 4K readings
// If value too high give error.
// Write ADC offset value to ADC peripheral
// Check IRQ is running at desired rate
//################################################################################################
int adc_offset_calculation(void) {
 #ifndef MATLAB_MEX_FILE
	int dn = 0;
	int timeout = 0;
	short this_error;
	short error = 0;
	int status_word;

	debug_printf(DBG_INFO, "ADC Offset calc\n");
	for (dn = platform.first_drive; dn <= platform.last_drive; dn++) {
		//timeout = 0;
		this_error = 0;

		dp[dn].Offset_start_calc = 0;
		dp[dn].enable_drive = 0;

		IOWR_16DIRECT(dp[dn].DOC_ADC_BASE_ADDR, ADC_OFFSET_U , 32767);
		IOWR_16DIRECT(dp[dn].DOC_ADC_BASE_ADDR, ADC_OFFSET_W , 32767);

		IOWR_16DIRECT(dp[dn].DOC_ADC_BASE_ADDR, ADC_D, 1);
		IOWR_16DIRECT(dp[dn].DOC_SM_BASE_ADDR, SM_CONTROL , 1 ); // Pre-Charge  State

		// Wait for 1 second
		//OSTimeDlyHMSM(0, 0, 1, 0);
		OSTimeDlyHMSM(0, 0, 0, 500);

		debug_printf(DBG_INFO, "---> --------------------------------------------------\n");
		debug_printf(DBG_INFO, "---> STATE %i of Motor \n", IORD_16DIRECT(dp[dn].DOC_SM_BASE_ADDR, SM_STATUS) >> 9);

		IOWR_16DIRECT(dp[dn].DOC_ADC_BASE_ADDR, ADC_OFFSET_U , 32767);  // Zero offset
		IOWR_16DIRECT(dp[dn].DOC_ADC_BASE_ADDR, ADC_OFFSET_W , 32767);

		dp[dn].Offset_U = 0;
		dp[dn].Offset_W = 0;
		// Set start for offset calculation in ISR
		dp[dn].Offset_start_calc = 1;

		//Wait for offset calculation to finish
		debug_printf(DBG_INFO, "---> Axis %d: Offset calc\n", dn);
		while (dp[dn].Offset_start_calc != 0) {
            adc_read(dp[dn].DOC_ADC_BASE_ADDR, &dp[dn].Iu, &dp[dn].Iw) ;
            adc_offset_accumulate((int *)(&dp[dn].Offset_start_calc), &dp[dn].Offset_U, &dp[dn].Offset_W, dp[dn].Iu, dp[dn].Iw);
			//OSTimeDlyHMSM(0, 0, 0, 100);
            OSTimeDlyHMSM(0, 0, 0, 1);
			timeout++;
			if (timeout > 10000) {
				this_error = 1;
				error = error + (1<<dn);
				break;
			}
		}


		if (this_error == 1) {
			debug_printf(DBG_ERROR, "---> --------------------------------------------------\n");
			debug_printf(DBG_ERROR, "---> Timeout in Offset Calc!\n");
			dp[dn].Offset_U = 0;
			dp[dn].Offset_W = 0;

			status_word = (0x0FFF & IORD_16DIRECT(dp[dn].DOC_SM_BASE_ADDR, SM_STATUS));

			if (status_word & (STATUS_REG_ERR_OV|STATUS_REG_ERR_UV|STATUS_REG_ERR_IGBT)) {
				debug_printf(DBG_ERROR, "---> Drive State Machine Errors = %s %s %s\n",
						status_word&STATUS_REG_ERR_OV?"DC_Link_Overvoltage":"",
						status_word&STATUS_REG_ERR_UV?"DC_Link_Undervoltage":"",
						status_word&STATUS_REG_ERR_IGBT?"IGBT_Error":""
				);
				debug_printf(DBG_ERROR, "---> ADC calibration failed due to above Drive State Machine Errors!\n");
				debug_printf(DBG_ERROR, "---> --------------------------------------------------\n");
			}
		} else {
			dp[dn].Offset_U = dp[dn].Offset_U / OFFSET_ACCUM_ISR_COUNT;
			dp[dn].Offset_W = dp[dn].Offset_W / OFFSET_ACCUM_ISR_COUNT;
			debug_printf(DBG_INFO, "---> Offset U: %i \n", (short) dp[dn].Offset_U);
			debug_printf(DBG_INFO, "---> Offset W: %i \n", (short) dp[dn].Offset_W);

			if ((abs(dp[dn].Offset_U) > CURRENT_OFFSET_LIMIT) || (abs(
					dp[dn].Offset_W) > CURRENT_OFFSET_LIMIT)) {
				error = error + (1<<(platform.powerboard->axes + dn));
				debug_printf(DBG_ERROR, "Error: ---> Axis %d: Offset calc unsuccessful! \n", dn);
			} else {
				IOWR_16DIRECT(dp[dn].DOC_ADC_BASE_ADDR, ADC_OFFSET_U , 32767+(short)dp[dn].Offset_U);
				IOWR_16DIRECT(dp[dn].DOC_ADC_BASE_ADDR, ADC_OFFSET_W , 32767+(short)dp[dn].Offset_W);
				debug_printf(DBG_INFO, "---> Axis %d: Offset calc successful! \n", dn);
			}
		}
		dp[dn].enable_drive = 0;
		IOWR_16DIRECT(dp[dn].DOC_ADC_BASE_ADDR, ADC_D, 0);
		IOWR_16DIRECT(dp[dn].DOC_SM_BASE_ADDR, SM_CONTROL , 0 ); // Init State
	}
	return error;
#endif
}

/**
 * @brief Sample encoder inputs
 *
 * Helper function to read motor position and current for a single axis
 *
 * @param dp	Pointer to axis data structure
 */
#ifndef MATLAB_MEX_FILE
static void sample_inputs(drive_params * dp, int dn) {

	// Read motor position from encoder
	platform.encoder->encoder_read_position_fn(dp);
	dp->phi_elec = PHI_ELECTRICAL(dp->mpoles, dp->phi_mech, dp->mphase);

	//position control NOT used but still calculates position values
	position_control(&dp->Position_PI,  dp->enc_data, &dp->enc_data_old, &dp->pos_temp, &dp->pos_int, dp->pos_setpoint_adjusted, dp->pos_limit, &dp->speed_command_adjusted,dp->encoder_singleturn_bits);
	//Set setpoint to actual measured position (not used but makes system console plot look better)
	dp->pos_setpoint_adjusted = dp->pos_int;
	dp->speed_command_adjusted = ABS_MAX(dp->speed_command, 3000 << SPEED_FRAC_BITS);

	// Speed Control
	//dp->Speed_PI.feedback = ABS_MAX(dp->speed_encoder + dp->cmd_wave_test,3000);
	dp->Speed_PI.feedback = dp->speed_encoder;
	dp->Speed_PI.setpoint = dp->speed_command_adjusted;
	PI_control_q15(& dp->Speed_PI, dp->reset_control);  //Direct current control
	dp->i_command_q =  dp->Speed_PI.output;

	if ( dp->enable_drive == 0 ){
		dp->i_command_q = 0 ;
	}
    // Read motor U & W phase currents from ADC
	adc_read(dp->DOC_ADC_BASE_ADDR, &dp->Iu, &dp->Iw) ;

    // Accumulate ADC readings for offset calibration
	adc_offset_accumulate((int *)(&dp->Offset_start_calc), &dp->Offset_U, &dp->Offset_W, dp->Iu, dp->Iw);
}
#endif


/**
 * Helper function called for each axis on each pass of motor task loop. Writes debug status
 * to and reads inputs from system console GUI.
 *
 * @param dn	drive axis to be updated
 */
static void	update_axis(
        int dn,
        int Current_Kp, 
        int Current_Ki, 
        int Current_PI_Limit, 
        int I_Limit, 
        int Speed_Kp, 
        int Speed_Ki,
        int Speed_PI_Limit) {
#ifndef MATLAB_MEX_FILE
    
#ifndef __SIMULINK__
    
	debug_write_status (dn, DOC_DBG_DRIVE_STATE, dp[dn].state_act);
	debug_write_status (dn, DOC_DBG_RUNTIME, runtime);
	debug_write_status (dn, DOC_DBG_DSP_MODE, enable_dspba);
	debug_write_status (dn, DOC_DBG_SPEED, dp[dn].speed_encoder >> SPEED_FRAC_BITS);
	debug_write_status (dn, DOC_DBG_POSITION, dp[dn].pos_int);
	debug_write_status (dn, DOC_DBG_LATENCY, latency);

	poll_debug (dn, &dp[0]);

#ifdef __NIOS__
				INIT_DSPBA_DOC_Single_Axis_dspba_fixp_regs (FOC_FIXED_POINT_BASE,
																	dp[dn].I_sat_limit,
																	dp[dn].Id_Ki,
																	dp[dn].Id_Kp,
																	dp[dn].V_sat_limit,
																	dn
																	);

				INIT_DSPBA_DOC_Single_Axis_dspba_floatp_regs (FOC_FLOATING_POINT_BASE,
																	dp[dn].I_sat_limit,
																	dp[dn].Id_Ki,
																	dp[dn].Id_Kp,
																	dp[dn].V_sat_limit,
																	dn
																	);
#else
	INIT_DSPBA_DOC_Single_Axis_dspba_filt_fixp_regs (DSPBA_FILT_FIXP_BASE, dp[dn].I_sat_limit, dp[dn].Id_Ki, dp[dn].Id_Kp,
			dp[dn].V_sat_limit, dp[dn].filt_struct0.a1_f, dp[dn].filt_struct0.a2_f, dp[dn].filt_struct0.b0_f, dp[dn].filt_struct0.b1_f, dp[dn].filt_struct0.b2_f,
			(dp[dn].filt_en == 1)?0:1, dp[dn].filt_struct0.dc_gain_f,dn);

	INIT_DSPBA_DOC_Single_Axis_dspba_filt_floatp_regs (DSPBA_FILT_FLOATP_BASE, dp[dn].I_sat_limit, dp[dn].Id_Ki, dp[dn].Id_Kp,
			dp[dn].V_sat_limit, dp[dn].filt_struct0.a1_f, dp[dn].filt_struct0.a2_f, dp[dn].filt_struct0.b0_f, dp[dn].filt_struct0.b1_f, dp[dn].filt_struct0.b2_f,
			(dp[dn].filt_en == 1)?0:1, dp[dn].filt_struct0.dc_gain_f, dn);
#endif
            
#endif

	dp[dn].Id_PI.Kp = Current_Kp;
	dp[dn].Id_PI.Ki = Current_Ki;
	dp[dn].Id_PI.feedback_limit = Current_PI_Limit;
	dp[dn].Id_PI.integrator_limit = I_Limit;
	dp[dn].Id_PI.output_limit = I_Limit;

	dp[dn].Iq_PI.Kp = Current_Kp;
	dp[dn].Iq_PI.Ki = Current_Ki;
	dp[dn].Iq_PI.feedback_limit = Current_PI_Limit;
	dp[dn].Iq_PI.integrator_limit = I_Limit;
	dp[dn].Iq_PI.output_limit = I_Limit;


	dp[dn].Speed_PI.Kp = Speed_Kp;
	dp[dn].Speed_PI.Ki = Speed_Ki;
	dp[dn].Speed_PI.feedback_limit = Speed_PI_Limit;
	dp[dn].Speed_PI.integrator_limit = I_Limit;
	dp[dn].Speed_PI.output_limit = I_Limit;

	dp[dn].Position_PI.Kp = dp[dn].pos_Kp;
	dp[dn].Position_PI.Ki = 0;
	//dp[dn].Position_PI.feedback_limit = 1073741824; //32000; //Max short_int
	//dp[dn].Position_PI.integrator_limit = 0;
	dp[dn].Position_PI.output_limit = dp[dn].pos_limit;

#ifndef __NIOS__
	dp[dn].cmd_wave_struct.Period_int32=dp[dn].cmd_wave_period; // Waveform period in 16kHz samples
	dp[dn].cmd_wave_struct.Offset_int32= dp[dn].cmd_wave_offset; // Waveform offset in 16kHz samples
	//dp[dn].cmd_wave_struct.Amp_ND_f=dp[dn].cmd_wave_amp_spd_rpm_f;   // Waveform amplitude, non-dimensional (to be multiplied by fullscale and units)
	dp[dn].cmd_wave_struct.Shape_enum=dp[dn].cmd_wave_type;    // Waveform type.


	//Setup filter input parameters before calling calcNotchCoeffs
	dp[dn].filt_struct_temp.Fn_Hz_f = dp[dn].filt_fn_hz_f;
	dp[dn].filt_struct_temp.Fd_Hz_f = dp[dn].filt_fd_hz_f;
	dp[dn].filt_struct_temp.zetan_ND_f = dp[dn].filt_zn_f;
	dp[dn].filt_struct_temp.zetad_ND_f = dp[dn].filt_zd_f;
	dp[dn].filt_struct_temp.dc_gain_f = dp[dn].filt_dc_gain_f;

	dp[dn].filt_struct_temp.T_s_f = 62.5e-06;

	calcNotchCoeffs(&dp[dn].filt_struct_temp);
#endif

#endif
}


/**
 * @brief Interrupt Service Routine for motor control
 *
 * All of the critical processing occurs here. The IRQ occurs every PWM cycle, which is every 62.5us in the
 * stamdard implementation, as a result of the ADC conversion completion interrupt.
 *
 * It is assumed that the hardware design is such that the position encoder reading is also
 * available.
 *
 * Processing must complete in time for the new PWM value to be written to the hardware before
 * the next cycle starts.
 *
 * @param context	Additional IRQ context
*/
void closed_loop(int mode, int speed_request, int Valpha, int Vbeta){
#ifndef MATLAB_MEX_FILE
	for (dn = platform.first_drive; dn <= platform.last_drive; dn++){
			dp[dn].speed_command = speed_request;
			sample_inputs(&dp[dn],dn);
	}
    process(mode, dp, Valpha, Vbeta);
#endif
}


/**
 * @brief Interrupt Service Routine for motor control
 *
 * All of the critical processing occurs here. The IRQ occurs every PWM cycle, which is every 62.5us in the
 * stamdard implementation, as a result of the ADC conversion completion interrupt.
 *
 * It is assumed that the hardware design is such that the position encoder reading is also
 * available.
 *
 * Processing must complete in time for the new PWM value to be written to the hardware before
 * the next cycle starts.
 *
 * @param context	Additional IRQ context
*/
void open_loop(unsigned int rev) {
#ifndef MATLAB_MEX_FILE
    int dn = 0;
    
    // Open loop mode
    static unsigned int idx = 0;
    unsigned short x1 ;
    // Create fixed frequency SVM to turn motor without current or position feedback
    idx = idx+(int)abs(rev*0.13); //150;
    x1  = idx>>2;
    //debug_printf(DBG_INFO, "[Motor task] Turning in open-loop mode %d\n", idx);
    
    for (dn = platform.first_drive; dn <= platform.last_drive; dn++){
        // Read motor position from encoder
        platform.encoder->encoder_read_position_fn(&dp[dn]);
        dp[dn].phi_elec = PHI_ELECTRICAL(dp[dn].mpoles, dp[dn].phi_mech, dp[dn].mphase);
        position_control(&dp[dn].Position_PI,  dp[dn].enc_data, &dp[dn].enc_data_old, &dp[dn].pos_temp, &dp[dn].pos_int, dp[dn].pos_setpoint, dp[dn].pos_limit, &dp[dn].speed_command,dp[dn].encoder_singleturn_bits);
        // Position not used - for monitoring only
        
        // Read motor U & W phase currents from ADC
        adc_read(dp[dn].DOC_ADC_BASE_ADDR, &dp[dn].Iu, &dp[dn].Iw);
        adc_offset_accumulate((int *)(&dp[dn].Offset_start_calc), &dp[dn].Offset_U, &dp[dn].Offset_W, dp[dn].Iu, dp[dn].Iw);
        clark_transform_q10(dp[dn].Iu,dp[dn].Iw,&dp[dn].Ialpha,&dp[dn].Ibeta);
        // Ialpha & Ibeta not used - for monitoring only
        
        dp[dn].Vbeta = SINE(x1)>>8;
        dp[dn].Valpha = COSINE(x1)>>8;
        // Space vector modulation for outputs
        svm(PWMMAX, dp[dn].Valpha, dp[dn].Vbeta, &dp[dn].Vu_PWM, &dp[dn].Vv_PWM, &dp[dn].Vw_PWM);
        // Write new PWM values to hardware ready for next cycle
        if (dp[dn].enable_drive == 1){
            pwm_update(dp[dn].DOC_PWM_BASE_ADDR, dp[dn].Vu_PWM, dp[dn].Vv_PWM, dp[dn].Vw_PWM);
        } else {
            // Disabled axes set stationary by setting PWM to midpoint
            pwm_update(dp[dn].DOC_PWM_BASE_ADDR, (PWMMAX+1)/2-1, (PWMMAX+1)/2-1, (PWMMAX+1)/2-1);
        }
    } // end for dn
    
    dn = 0;
    dn = axis_select;
#endif
}


double do_mc_startup(
    int Current_Kp,
    int Current_Ki,
    int Current_PI_Limit,
    int I_Limit,
    int Speed_Kp, 
    int Speed_Ki,
    int Speed_PI_Limit){
    
#ifndef MATLAB_MEX_FILE
    
    int fd;
    if( ( fd = open( "/dev/mem", ( O_RDWR | O_SYNC ) ) ) == -1 ) {
        debug_printf(DBG_INFO, "ERROR: could not open \"/dev/mem\"...\n" );
        return( 1 );
    }
    virtual_base = mmap( NULL, HW_REGS_SPAN, ( PROT_READ | PROT_WRITE ), MAP_SHARED, fd, HW_REGS_BASE );
    if( virtual_base == MAP_FAILED ) {
        debug_printf(DBG_INFO, "ERROR: mmap() failed...\n" );
        close( fd );
        return( 1 );
    }
    
    init_debug_output();
    debug_printf(DBG_INFO, "[Motor task] Hello!\n");
    
    memset(&platform, 0, sizeof(platform_t));
    
    if (decode_sysid(SYSID_0_BASE) > 0) {
        while (1) {
            OSTimeDlyHMSM(0, 0, 1, 0);
        }
    }
    
    init_sin_cos_tables();
    
#ifndef __SIMULINK__
    enable_dspba = SOFT_FIXP;
#endif
    init_dp(&dp[0]);
#ifndef __SIMULINK__
    debug_get_buttons((17 * 4), 5, &buttons);
#endif
    
    // Initialise all drives
    // Leave this as 0 to platform.last_drive for debug interface
    for (dn = 0; dn <= platform.last_drive; dn++) { //MAX
        init_axis(dn, Current_Kp, Current_Ki, Current_PI_Limit, I_Limit, Speed_Kp, Speed_Ki, Speed_PI_Limit);
    }
    
    //PERF_RESET (PERFORMANCE_COUNTER_0_BASE);
    
    debug_printf(DBG_INFO, "[Motor task] Reset drive state machines\n");
    // PWM modules must be setup for all channels up to platform.last_drive
    // to ensure consistent synchronisation
    // At present we only use IRQ from channel 0 ADC, but set them all
    // up here.
    for (dn = 0; dn <= platform.last_drive; dn++) {
        dsm_reset_to_idle(dp[dn].DOC_SM_BASE_ADDR);
        pwm_setup(dp[dn].DOC_PWM_BASE_ADDR,PWMMAX);
        adc_setup(dp[dn].DOC_ADC_BASE_ADDR);
    }
    
#ifdef JTAG_UART_BASE
    IOWR_ALTERA_AVALON_JTAG_UART_CONTROL(JTAG_UART_BASE,0);
#endif
    
    //Configure the DC link
    debug_printf(DBG_INFO, "[Motor task] Configure DC link\n");
    dc_link_setup();
    OSTimeDlyHMSM(0, 0, 0, 1);
    
    
    //Check the DC link voltage measurement
    debug_printf(DBG_INFO, "[Motor task] Check DC Link\n");
    dc_link_voltage_check();
    debug_printf(DBG_INFO, "[Motor task] ---> Setting state to 6 \n");
#ifndef __SIMULINK__
    debug_write_status (0, DOC_DBG_DRIVE_STATE, 6); //passed voltage test
#endif
    debug_printf(DBG_INFO, "[Motor task] ---> ------------------------------------\n");
    debug_printf(DBG_INFO, "[Motor task] ---> DC_Link : %i V\n", dc_link_voltage);
    if (platform.powerboard->sysid == SYSID_PB_ALT12_MULTIAXIS) {
        // Altera power board has DC link current sense
        debug_printf(DBG_INFO, "[Motor task] --->         : %i mA\n",dc_link_current);
    }
    
    dc_link_chopper_setup();
    
    
#ifndef LOOPBACK
    // Initialise Encoders
    debug_printf(DBG_INFO, "[Motor task] %s Initialization\n", platform.encoder->name);
    for (dn = platform.first_drive; dn <= platform.last_drive; dn++){//MAX
        debug_printf(DBG_INFO, "[Motor task] --------------------------------------------------------------------------\n");
        debug_printf(DBG_INFO, "[Motor task] %s init for channel %d\n", platform.encoder->name, dn);
        if (platform.encoder->encoder_init_fn(&dp[dn]) != 0) {;
        debug_printf(DBG_ERROR, "[Motor task] %s communication failed for channel %d\n", platform.encoder->name, dn);
        while (1) {
            OSTimeDlyHMSM(0, 0, 0, 1);
        }
        } else {
            debug_printf(DBG_INFO, "[Motor task] %s parameters for channel %d\n", platform.encoder->name, dn);
            debug_printf(DBG_INFO, "[Motor task] Commutation-Angle : %i count\n", dp[dn].mphase);
            debug_printf(DBG_INFO, "[Motor task] %s actual      : %d  Bit\n", platform.encoder->name, dp[dn].encoder_length);
            debug_printf(DBG_INFO, "[Motor task] Multiturn para    : %i\n", dp[dn].encoder_multiturn);
            debug_printf(DBG_INFO, "[Motor task] Multiturn         : %i\tBit\n", dp[dn].encoder_multiturn_bits);
            debug_printf(DBG_INFO, "[Motor task] Singleturn        : %i\tBit\n", dp[dn].encoder_singleturn_bits);
            debug_printf(DBG_INFO, "[Motor task] Resolution mask   : 0x%x\n", dp[dn].encoder_mask);
            debug_printf(DBG_INFO, "[Motor task] Turns mask        : 0x%x\n", dp[dn].encoder_turns_mask);
        }
        if (dp[dn].encoder_version > 0)
            debug_printf(DBG_INFO, "[Motor task] Version of %s interface  V%i.2 \n", platform.encoder->name, dp[dn].encoder_version);
    };
    
    debug_printf(DBG_INFO, "[Motor task] ---> Setting state to 7 \n");
#ifndef __SIMULINK__
    debug_write_status (0, DOC_DBG_DRIVE_STATE, 7); //passed EnDat test
#endif
#else
    debug_printf(DBG_INFO, "[Motor task] Skipping %s Initialization in LOOPACK mode\n", platform.encoder->name);
#endif
    // Enable drive IRQ in CPU interrupt controller
#ifdef __DOC_SOC_UCOSII__
    CSP_IntEn((CSP_DEV_NBR   )CSP_INT_CTRL_NBR_MAIN,
            (CSP_DEV_NBR   )DRIVE0_ADC_IRQ_NUM);
#else
#ifdef __DOC_SOC_VXWORKS__
    intEnable(DRIVE0_ADC_IRQ_NUM);
#else
#ifdef __NIOS__
#ifndef __SIMULINK__
    alt_ic_isr_register(0, DRIVE0_DOC_ADC_IRQ, drive_irq, NULL, NULL);
#endif
#else
#error "Unsupported OS"
#endif
#endif
#endif
    
    
#ifdef ENCODER_SERVICE
    debug_printf(DBG_INFO, "[Motor task] Encoder service mode\n");
    for (dn = platform.first_drive; dn <= platform.last_drive; dn++){
        dsm_reset_to_idle(dp[dn].DOC_SM_BASE_ADDR);
        dp[dn].openloop_test = 0;
        encoder_service_fn(&dp[dn]);
    }
    debug_printf(DBG_INFO, "[Motor task] Program stopped\n");
    return 0;
#endif
    
#ifdef LOOPBACK
//		int overvoltage = 65535;
    IOWR_16DIRECT(DOC_DC_LINK_BASE, DOC_DC_LINK_OVERVOLTAGE , 65535);
//		IOWR_16DIRECT(DOC_DC_LINK_BASE, DOC_DC_LINK_OVERVOLTAGE , overvoltage*82*32767)/(64*1996));
#endif
    
    //Enable the PWMs after setting up the EnDat / Biss encoders
    for (dn = 0; dn <= platform.last_drive; dn++) {
        dsm_reset(dp[dn].DOC_SM_BASE_ADDR);
        pwm_setup(dp[dn].DOC_PWM_BASE_ADDR,PWMMAX);
        adc_setup(dp[dn].DOC_ADC_BASE_ADDR);
    }
    
//#ifndef __SIMULINK__
#ifdef LOOPBACK
    // No power board connected, loop here running ADC calibration
    while (1) {
    
        if (adc_offset_calculation()>0) {
            restart_drive = 1;  //loop restarting the drive if error
        }
       
    }
#else
    if (adc_offset_calculation()>0) {
        restart_drive = 1;  //loop restarting the drive if error
    }
#endif
    
    if (restart_drive == 1) {
        debug_printf(DBG_ERROR, "[Motor task] ---> Failure detected in ADC calibration. Check power connection. \n");
    }
//#endif
    
#ifndef __NIOS__
    fft_0.fft_enable = 1;
    fft_1.fft_enable = 1;
#endif
    
#endif
    
    return 0;
}

double do_mc(
	int mode,
    int reset_input,
	int speed_request,
    int Valpha, 
	int Vbeta,
    int Current_Kp,
    int Current_Ki,
    int Current_PI_Limit,
    int I_Limit,
    int Speed_Kp, 
    int Speed_Ki,
    int Speed_PI_Limit, 
	short *dc_link_voltage_C, 
	int *speed_encoder_C, 
	unsigned short *phi_mech_C, 
	unsigned short  *phi_elec_C,
	int *pos_int_C,
	short *Iu_C, 
	short *Iw_C,
    int *Id_C,
    int *Iq_C,
    int *IntegralD_C,
    int *IntegralQ_C,
	int *Vu_PWM_C,
	int *Vv_PWM_C,
	int *Vw_PWM_C,
	int *Valpha_C, 
	int *Vbeta_C, 
	int *I_command_q_C,
    int *Error_d_C,
    int *Error_q_C){

#ifndef MATLAB_MEX_FILE

    if (counter==0){
        gettimeofday(&start, NULL);
		micros_used = 0;
        counter++;
    }else if (counter==9999){
        gettimeofday(&end, NULL);
        secs_used=(end.tv_sec - start.tv_sec);
        micros_used += ((secs_used*1000000) + end.tv_usec) - (start.tv_usec);
       	debug_printf(DBG_INFO, "Every 10000 updates takes %f ms\n", micros_used/1000.0);
        counter=0;
    }else{
        counter++;
    }
	

    // Service all drives
    // Leave this as 0 to platform.last_drive for debug interface
    for (dn = 0; dn <= platform.last_drive; dn++){ //MAX
        update_axis(dn, Current_Kp, Current_Ki, Current_PI_Limit, I_Limit, Speed_Kp, Speed_Ki, Speed_PI_Limit);
    }
    
#ifndef __SIMULINK__   
    axis_select = debug_read_command (0, DOC_DBG_AXIS_SELECT);
    
#ifndef __NIOS__
    fft_0.fft_axis = axis_select;
    fft_1.fft_axis = axis_select;
#endif
    

    debug_get_buttons((17 * 4), 5, &buttons);
#endif
       
    // Drive state machine
    for (dn = platform.first_drive; dn <= platform.last_drive; dn++){ //MAX
        if (dp[dn].state_act != 3 ) { //Disable Motor when not in Run State
            dp[dn].enable_drive = 0 ;
        }
        
        dp[dn].state_act_old  = dp[dn].state_act;
        dp[dn].status_word = (0x0FFF & IORD_16DIRECT(dp[dn].DOC_SM_BASE_ADDR, SM_STATUS));
        dp[dn].state_act	= dp[dn].status_word >> 9;
        if (dp[dn].state_act != dp[dn].state_act_old) {
            debug_printf(DBG_INFO, "Axis %d: State now %d  Status=%04X\n", dn, dp[dn].state_act, dp[dn].status_word);
        }
        
        switch (dp[dn].state_act) {
            case 0: /***Init*************/
                dp[dn].enable_drive = 0 ;                          // Reset current controller command values and SVM output voltage
#ifndef __SIMULINK__
                debug_write_status (dn, DOC_DBG_DRIVE_STATE, 0);
                runtime =0 ;
                cnt_IRQ =0 ;
#endif
                adc_overcurrent_enable(dp[dn].DOC_ADC_BASE_ADDR,0);     // overcurrent measurement disabled
                OSTimeDlyHMSM(0, 0, 0, 250);
                IOWR_16DIRECT(dp[dn].DOC_SM_BASE_ADDR, SM_CONTROL , 1) ;
                break;
                
            case 1: /***Precharge********/
                // go straight to state 2
#ifndef __SIMULINK__
                debug_write_status (dn, DOC_DBG_DRIVE_STATE, 1);
#endif
                OSTimeDlyHMSM(0, 0, 0, 250);
                IOWR_16DIRECT(dp[dn].DOC_SM_BASE_ADDR, SM_CONTROL, 2) ;
                break;
                
            case 2: /***Prerun**********/
#ifndef __SIMULINK__
                debug_write_status (dn, DOC_DBG_DRIVE_STATE, 2);
#endif
                adc_overcurrent_enable(dp[dn].DOC_ADC_BASE_ADDR,1); // enable overcurrent measure
                // go straight to state 3
                OSTimeDlyHMSM(0, 0, 0, 250);
                IOWR_16DIRECT(dp[dn].DOC_SM_BASE_ADDR, SM_CONTROL, 3) ;
                break;
                
            case 3: /***Run*************/
                dp[dn].enable_drive = 1 ;
                dp[dn].reset_control = reset_input;
#ifdef __SIMULINK__
				if (mode==0){
					open_loop(speed_request);
				}else{
					closed_loop(mode, speed_request, Valpha, Vbeta);
				}
				// Return values
				*phi_mech_C = dp[0].phi_mech;
				*phi_elec_C = dp[0].phi_elec;
				*pos_int_C = dp[0].pos_int;
				*speed_encoder_C = dp[0].speed_encoder;
				*Iu_C = dp[0].Iu;
				*Iw_C = dp[0].Iw;
                *IntegralD_C = dp[0].Id_PI.integrator;
                *IntegralQ_C = dp[0].Iq_PI.integrator;
                *Id_C = dp[0].Id;
                *Iq_C = dp[0].Iq;
				*Vu_PWM_C = dp[0].Vu_PWM;
				*Vv_PWM_C = dp[0].Vv_PWM;
				*Vw_PWM_C = dp[0].Vw_PWM;
				*Valpha_C = dp[0].Valpha;
				*Vbeta_C = dp[0].Vbeta;
				dc_link_read(&dc_link_voltage, &dc_link_current);
				*dc_link_voltage_C = dc_link_voltage;
				*I_command_q_C = dp[0].i_command_q;
                *Error_d_C = dp[0].Id_PI.setpoint - dp[0].Id_PI.feedback;
                *Error_q_C = dp[0].Iq_PI.setpoint - dp[0].Iq_PI.feedback;
#endif
                break;
                
            case 4:
                // Error state
                restart_drive = 1;
                decode_error_state(dn);
                OSTimeDlyHMSM(0, 0, 0, 10);
                break;
        }
    }
    //OSTimeDlyHMSM(0, 0, 0, 100);

#ifndef __SIMULINK__
    restart_drive |= soft_button_scan(buttons);
#endif
    
#ifdef __SIMULINK__
    if (restart_drive == 1){
        decode_error_state(0);
        decode_error_state(1);
        decode_error_state(2);
        decode_error_state(3);
        restart_all_drives();
        
        debug_printf(DBG_INFO, "\n[Motor task] Resetting drives please wait... \n");
        OSTimeDlyHMSM(0, 0, 3, 0);
        restart_drive = 0;
        // Call initialization function.
        do_mc_startup(Current_Kp, Current_Ki, Current_PI_Limit, I_Limit, Speed_Kp, Speed_Ki, Speed_PI_Limit);
    }
#endif
    

#endif
    
    return 0;
}


double do_mc_shutdown(){
    
#ifndef MATLAB_MEX_FILE
#endif
    
    return 0;
}