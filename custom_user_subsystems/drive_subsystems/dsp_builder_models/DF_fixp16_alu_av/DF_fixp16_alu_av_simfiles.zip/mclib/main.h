int adc_offset_calculation(void);
void closed_loop(int mode, int speed_request, int Valpha, int Vbeta);
void open_loop(unsigned int rev);
double do_mc_startup(
    int Current_Kp,
    int Current_Ki,
    int Current_PI_Limit,
    int I_Limit,
    int Speed_Kp, 
    int Speed_Ki,
    int Speed_PI_Limit);
double do_mc(
	int mode,
    int reset_input,
	int speed_request,
    int Valpha, 
	int Vbeta, 
    int Current_Kp,
    int Current_Ki,
    int Current_PI_Limit,
    int I_Limit,
    int Speed_Kp, 
    int Speed_Ki,
    int Speed_PI_Limit,
	short *dc_link_voltage_C, 
	int *speed_encoder_C, 
	unsigned short *phi_mech_C, 
	unsigned short  *phi_elec_C,
	int *pos_int_C,
	short *Iu_C, 
	short *Iw_C,
    int *Id_C,
    int *Iq_C,
    int *IntegralD_C,
    int *IntegralQ_C,
	int *Vu_PWM_C,
	int *Vv_PWM_C,
	int *Vw_PWM_C,
	int *Valpha_C, 
	int *Vbeta_C, 
	int *I_command_q_C,
    int *Error_d_C,
    int *Error_q_C);
double do_mc_shutdown();