//################################################################################################
// Space Vector Modulation - DC ( angle & absolute value ) --> Spacevector ( depends on switching time like PWM )
//################################################################################################
void svm_interface(
                    unsigned short pwm_max,
                    int u_a,
                    int u_b,
                    unsigned short * ru_out,
                    unsigned short * rv_out,
                    unsigned short * rw_out
                    )
{
    const short     c0577 = 18919 ; // 32768 / sqrt(3)
    unsigned short  tmax  = pwm_max;
    int             ru,rv,rw ;
    // Scale inputs to maximum PWM count
    int v_alpha = (u_a*tmax);
    v_alpha = v_alpha>>15;
    int v_beta = (u_b*tmax);
    v_beta = v_beta>>15;

    v_beta = (v_beta * c0577) >> 15 ;  //Note: scale by 1/sqrt(3) for *u_b* only
    if ( v_alpha >= 0 ) {
        if ( v_beta >= 0 ){
            if ( v_alpha < v_beta ) goto sector_2 ;
            //   SVM sector 1
            rv =  v_alpha - v_beta ;                  //   t1 =   u_a - u_b ;
            rw =  v_beta + v_beta ;                  //   t2 =   2 * u_b ;
            ru = (tmax + rv + rw) >> 1 ;
            rv = ru - rv ;
            rw = rv - rw ;
        } else {
            if ( v_alpha < -v_beta ) goto sector_5 ;
            //   SVM sector 6
            rv = - v_beta - v_beta ;                  //   t1 =  -2 * u_b ;
            rw =   v_alpha + v_beta ;                  //   t2 =  u_a + u_b ;
            ru = (tmax + rw+ rv) >> 1 ;
            rw = ru - rw ;
            rv = rw - rv ;
               }
    } else {
        if ( v_beta >= 0 ){
            if ( -v_alpha >= v_beta ) {
                //   SVM sector 3
                rw =   v_beta + v_beta ;                  //   t1 =   2 *u_b ;
                ru =  -v_alpha - v_beta ;                  //   t2 = - u_a - u_b ;
                rv = (tmax + ru + rw) >> 1 ;
                rw = rv - rw ;
                ru = rw - ru;
            } else {
            	sector_2:   // SVM sector 2
                rw =    v_alpha + v_beta ;                  //   t1 =   u_a + u_b ;
                ru =   -v_alpha + v_beta ;                  //   t2 =  -u_a + u_b ;
                rv = (tmax + ru + rw) >> 1 ;
                ru = rv - ru ;
                rw = ru - rw ;
            }
        } else {
            if ( v_alpha < v_beta ) {
                // SVM sector 4
                ru =  -v_alpha + v_beta ;                  //   t1 = -u_a + u_b ;
                rv =  -v_beta - v_beta ;                  //   t2 =  -2 * u_b ;
                rw = (tmax + ru + rv) >> 1 ;
                rv = rw - rv ;
                ru = rv - ru ;
            } else {
            	sector_5:
                // SVM sector 5
                ru =  -v_alpha - v_beta ;                  //   t1 = -u_a - u_b ;
                rv =   v_alpha - v_beta ;                  //   t2 =  u_a - u_b ;
                rw = (tmax + ru + rv) >> 1 ;
                ru = rw - ru ;
                rv = ru - rv ;
            }
        }
    }

    if ( ru < 0 ) {
        ru = 0;
    } else if( ru > tmax ) {
        ru = tmax ;
    }
    *ru_out = (unsigned short)ru;
    if ( rv < 0 ) {
        rv = 0 ;
    } else if ( rv > tmax ) {
        rv = tmax ;
    }
    *rv_out = (unsigned short)rv;
    if ( rw < 0 ) {
        rw = 0 ;
    } else if( rw > tmax ) {
        rw = tmax ;
    }
    *rw_out = (unsigned short)rw;
}
