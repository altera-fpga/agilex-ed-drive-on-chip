void svm_interface(
                    unsigned short pwm_max,
                    int u_a,
                    int u_b,
                    unsigned short * ru_out,
                    unsigned short * rv_out,
                    unsigned short * rw_out
                    );