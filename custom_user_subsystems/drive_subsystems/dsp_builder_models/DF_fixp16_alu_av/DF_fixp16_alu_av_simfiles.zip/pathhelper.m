function thispath = pathhelper

thispath = fileparts(mfilename('fullpath'));