/* ##########################################################################
 * Copyright 2015 - 2024 Intel Corporation.
 *
 * This software and the related documents are Intel copyrighted materials, f
 * and your use of them is governed by the express license under which they
 * were provided to you ("License"). Unless the License provides otherwise,
 * you may not use, modify, copy, publish, distribute, disclose or transmit
 * this software or the related documents without Intel's prior written permission.
 *
 * This software and the related documents are provided as is, with no express
 * or implied warranties, other than those that are expressly stated in the License.
 * ##########################################################################
 */

/**
 * @file drive_on_chip.c
 *
 * @brief Interface functions for Debug Mem of Drive-On-Chip (for visualization only)
 */

#include "drive_on_chip.h"

/**
 * @brief safe_gui_write_fpgapayload ().
 *
 * Refresh the fpga payload in the DoC dump memory for visualization for GUI
 */
void safe_gui_write_fpgapayload(unsigned int *gui_mem_address, unsigned int fpga_payload)
{
    *(gui_mem_address+DOC_SAFE_FPGA_PAYLOAD) = fpga_payload;

}

/**
 * @brief safe_gui_write_fpgainfo ().
 *
 * Refresh the fpga info in the DoC dump memory for visualization for GUI
 */
void safe_gui_write_fpgainfo(unsigned int *gui_mem_address, unsigned int fpga_info)
{
    *(gui_mem_address+DOC_SAFE_FPGA_INFO) = fpga_info;

}

/**
 * @brief safe_gui_write_hpspayload ().
 *
 * Refresh the hps payload in the DoC dump memory for visualization for GUI
 */
void safe_gui_write_hpspayload(unsigned int *gui_mem_address, unsigned int hps_payload)
{
    *(gui_mem_address+DOC_SAFE_HPS_PAYLOAD) = hps_payload;

}

/**
 * @brief safe_gui_write_hpsinfo ().
 *
 * Refresh the hps info in the DoC dump memory for visualization for GUI
 */
void safe_gui_write_hpsinfo(unsigned int *gui_mem_address, unsigned int hps_info)
{
    *(gui_mem_address + DOC_SAFE_HPS_INFO) = hps_info;

}

/**
 * @brief safe_gui_write_safestate ().
 *
 * Refresh the safe state in the DoC dump memory for visualization for GUI
 */
void safe_gui_write_safestate(unsigned int *gui_mem_address, unsigned int safe_state)
{
    *(gui_mem_address + DOC_SAFE_STATE) = safe_state;

}

/**
 * @brief set_doc_speed ().
 *
 * Set the speed of the DoC
 */
void set_doc_speed(unsigned int *doc_mem_address, int speed_rpm)
{
    *(doc_mem_address + DOC_DBG_SPEED_SETP0) = (speed_rpm * 65536) / 360;
    // *(doc_mem_address + DOC_DBG_SPEED_SETP0) = (speed_rpm);

}

/**
 * @brief change_demo_mode ().
 *
 * Change the demo mode after safe state
 */
void change_demo_mode(unsigned int *doc_mem_address, int demo_mode)
{
    *(doc_mem_address + DOC_DBG_DEMO_MODE) = demo_mode;

}

/**
 * @brief get_demo_mode ().
 *
 * Get the current demo mode in memory
 */
int get_demo_mode(unsigned int *doc_mem_address)
{
    return *(doc_mem_address + DOC_DBG_DEMO_MODE);

}


/*!
 * @}
 */
