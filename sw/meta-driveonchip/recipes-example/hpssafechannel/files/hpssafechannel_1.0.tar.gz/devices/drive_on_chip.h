/* ##########################################################################
 * Copyright 2015 - 2024 Intel Corporation.
 *
 * This software and the related documents are Intel copyrighted materials,
 * and your use of them is governed by the express license under which they
 * were provided to you ("License"). Unless the License provides otherwise,
 * you may not use, modify, copy, publish, distribute, disclose or transmit
 * this software or the related documents without Intel's prior written permission.
 *
 * This software and the related documents are provided as is, with no express
 * or implied warranties, other than those that are expressly stated in the License.
 * ##########################################################################
 */

/**
 * @file drive_on_chip.h
 *
 * @brief Interface functions and constants for Drive On Chip Driver
 */

#define DEBUG_ADDR_SPACE_PER_AXIS           66      //!< Size (32 but words) of debug memory for each axis

/*!
 *
 * Word (32-bit) addresses for debug memory
 * (WORD) ADDRESS MAP FOR DEBUG MEMORY
 * Write-only registers will polled only by System Console
 * Read-only registers (including button registers) will be polled in main loop
 *
 */

// General Drive Status (Write only)
#define DOC_DBG_DRIVE_STATE                 0
#define DOC_DBG_RUNTIME                     1
#define DOC_DBG_DSP_MODE                    2
#define DOC_DBG_APP_STATE                   3
#define DOC_DBG_LATENCY1                    4
#define DOC_DBG_DUMP_MODE                   5
#define DOC_DBG_TRIG_SEL                    6
#define DOC_DBG_TRIG_EDGE                   7
#define DOC_DBG_TRIG_VALUE                  8

// Drive Performance Status (Write only)
#define DOC_DBG_SPEED                       10      // Speed feedback (read)
#define DOC_DBG_POSITION                    12      // Position feedback (read)
#define DOC_DBG_BUTTON_DSP_MODE             13      // Mode  Software/DSP BA hardware
#define DOC_DBG_BUTTON_DRIVE_RESET          14
#define DOC_DBG_DEMO_MODE                   15      // Demo mode, i.e., commutation, control algorithm, etc.

#define DOC_DBG_I_PI_KP                     18      // Current control Kp
#define DOC_DBG_I_PI_KI                     19      // Current control Ki
#define DOC_DBG_SPEED_PI_KP                 20      // Speed control Kp
#define DOC_DBG_SPEED_PI_KI                 21      // Speed control Ki
#define DOC_DBG_SPEED_SETP0                 22      // Speed set point or command
#define DOC_DBG_AXIS_SELECT                 23      // Select to write on different axis

#define DOC_DBG_POS_SETP0                   25      // Position set point or command

#define DOC_DBG_WAVE_DEMO_MODE              29      // Speed/position waveform demo mode
#define DOC_DBG_POS_SPEED_LIMIT             30      // Speed limit for position mode demos
#define DOC_DBG_POS_PI_KP                   31      // Speed control Kp

#define DOC_DBG_WAVE_DEMO_PERIOD            33      // Speed/position demo waveform period
#define DOC_DBG_WAVE_DEMO_OFFSET            34      // Speed/position demo waveform time offset
#define DOC_DBG_WAVE_DEMO_WAVEFORM          35      // Speed/position demo waveform shape
#define DOC_DBG_WAVE_DEMO_AMP_F             36      // Speed/position demo waveform amplitude

#define DOC_DBG_DCDC_V_SETP0                44
#define DOC_DBG_DC_DC_V_LINK                54
#define DOC_DBG_ADC_TYPE                    55
#define DOC_DBG_LATENCY2                    56
#define DOC_DBG_LATENCY3                    57
#define DOC_DBG_TRACE_DEPTH                 58      // Waveform trace depth
#define DOC_DBG_TRIGGER_POS                 59      // Waveform trigger position
#define DOC_DBG_TRACE_SAMPLES               60      // Waveform trace sample skip
#define DOC_DBG_DEMO_UPDATE				    61      // Waveform demo update flag

/*WARNING, this is only for visualization, check the DOC memory space in NIOSV/g
 * embeeded program, so this are available to use
 */
#define DOC_SAFE_FPGA_PAYLOAD               0		//<! Memory space to allocate FPGA safety payload
#define DOC_SAFE_FPGA_INFO                  1		//<! Memory space to allocate FPGA safety info
#define DOC_SAFE_HPS_PAYLOAD                2		//<! Memory space to allocate HPS safety payload
#define DOC_SAFE_HPS_INFO                   3		//<! Memory space to allocate HPS safety info
#define DOC_SAFE_STATE                      4		//<! Memory space to allocate HPS safety info

/*Instance of Drive-On-Chip control memory functions detailed in drive_on_chip.c*/

void safe_gui_write_fpgapayload(unsigned int *gui_mem_address, unsigned int fpga_payload);
void safe_gui_write_fpgainfo(unsigned int *gui_mem_address, unsigned int fpga_info);
void safe_gui_write_hpspayload(unsigned int *gui_mem_address, unsigned int hps_payload);
void safe_gui_write_hpsinfo(unsigned int *gui_mem_address, unsigned int hps_info);
void safe_gui_write_safestate(unsigned int *gui_mem_address, unsigned int safe_state);
void set_doc_speed(unsigned int *doc_mem_address, int speed_rpm);
void change_demo_mode(unsigned int *doc_mem_address, int demo_mode);
int get_demo_mode(unsigned int *doc_mem_address);

/*!
 * @}
 */
