/* ##########################################################################
 * Copyright 2015 - 2024 Intel Corporation.
 *
 * This software and the related documents are Intel copyrighted materials, f
 * and your use of them is governed by the express license under which they
 * were provided to you ("License"). Unless the License provides otherwise,
 * you may not use, modify, copy, publish, distribute, disclose or transmit
 * this software or the related documents without Intel's prior written permission.
 *
 * This software and the related documents are provided as is, with no express
 * or implied warranties, other than those that are expressly stated in the License.
 * ##########################################################################
 */

/**
 * @file fpga_speed_est.c
 *
 * @brief Functions for the speed estimator in the FPGA channel
 */

#include "fpga_speed_est.h"

/**
 * @brief clear_over_speed_latch function for FPGA speed estimator.
 *
 * Clears the status bits of the FPGA channel speed estimator.
 */
void clear_over_speed_latch(unsigned int *fpga_speed_est_base)
{
    *(fpga_speed_est_base + FPGA_SPEED_EST_CONTROL) =  FPGA_SE_RESET_STATUS_BITS;
}

/*!
 * @}
 */
