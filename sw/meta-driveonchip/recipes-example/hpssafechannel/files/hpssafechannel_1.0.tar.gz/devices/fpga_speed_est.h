/* ##########################################################################
 * Copyright 2015 - 2024 Intel Corporation.
 *
 * This software and the related documents are Intel copyrighted materials,
 * and your use of them is governed by the express license under which they
 * were provided to you ("License"). Unless the License provides otherwise,
 * you may not use, modify, copy, publish, distribute, disclose or transmit
 * this software or the related documents without Intel's prior written permission.
 *
 * This software and the related documents are provided as is, with no express
 * or implied warranties, other than those that are expressly stated in the License.
 * ##########################################################################
 */

/**
 * @file fpga_speed_estimator.h
 *
 * @brief Interface functions and constants for the speed estimator in the FPGA channel
 */

#define FPGA_SPEED_EST_CONTROL                  0
#define FPGA_SPEED_EST_BASE_FREQ                1
#define FPGA_SPEED_EST_SAMPLING_FREQ            2
#define FPGA_SPEED_EST_THRESHOLD                3
#define FPGA_SPEED_EST_STATUS                   4

#define FPGA_SE_RESET_STATUS_BITS               0x3

/*Instance of FPGA SE functions detailed in fpga_speed_estimator.c*/
void clear_over_speed_latch(unsigned int *fpga_speed_est_base);

/*!
 * @}
 */
