/* ##########################################################################
 * Copyright 2015 - 2024 Intel Corporation.
 *
 * This software and the related documents are Intel copyrighted materials,
 * and your use of them is governed by the express license under which they
 * were provided to you ("License"). Unless the License provides otherwise,
 * you may not use, modify, copy, publish, distribute, disclose or transmit
 * this software or the related documents without Intel's prior written permission.
 *
 * This software and the related documents are provided as is, with no express
 * or implied warranties, other than those that are expressly stated in the License.
 * ##########################################################################
 */

/**
 * @file hps_gpio.c
 *
 * @brief Interface functions for the HPS GPIO outputs to the ESL
 */

#include "speed_estimation.h"
#include "hps_gpio.h"


/**
 * @brief write_hps_gpio function for GPIO ESL.
 *
 * Used to register the outputs of comparison and
 *  overspeed to the ESL. It uses _p and _n  signals
 *
 */
int write_hps_gpio(unsigned int *hps_gpio_base, unsigned int gpio_output)
{
    *(hps_gpio_base + HPS_GPIO_OUT_OFFSET) =  gpio_output;
    return 0;

}

/*
 * @brief read_hps_gpio function for GPIO ESL.
 * The function is a helper funtion to retrieve the values written
 * in the GPIO block by the HPS. Mostly for debugging purposes.
 */
int read_hps_gpio(unsigned int *hps_gpio_base)
{
    return *(hps_gpio_base + HPS_GPIO_OUT_OFFSET);

}

/*
 * @brief read_hps_gpio_safe_state function from ESL
 * that indicates if the drive went into safe state.
 */
int read_hps_gpio_safe_state(unsigned int *hps_gpio_base)
{
    return *(hps_gpio_base + HPS_GPIO_IN_OFFSET);

}

/*!
 * @}
 */
