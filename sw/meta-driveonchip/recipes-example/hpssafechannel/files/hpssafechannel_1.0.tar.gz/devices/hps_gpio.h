/* ##########################################################################
 * Copyright 2015 - 2024 Intel Corporation.
 *
 * This software and the related documents are Intel copyrighted materials,
 * and your use of them is governed by the express license under which they
 * were provided to you ("License"). Unless the License provides otherwise,
 * you may not use, modify, copy, publish, distribute, disclose or transmit
 * this software or the related documents without Intel's prior written permission.
 *
 * This software and the related documents are provided as is, with no express
 * or implied warranties, other than those that are expressly stated in the License.
 * ##########################################################################
 */

/**
 * @file hps_gpio.h
 *
 * @brief Interface functions and constants for GPIO outputs to the ESL
 */

#define HPS_GPIO_OUT_OFFSET                 0x0
#define HPS_GPIO_IN_OFFSET                  0x1

#define GPIO_RESULTS_MSK                    0xF
#define HPS_IS_SAFE_P_MSK                   (0)
#define HPS_IS_SAFE_N_MSK                   (1)
#define HPS_COMP_GOOD_P_MSK                 (2)
#define HPS_COMP_GOOD_N_MSK                 (3)
#define HPS_MOTOR_POWERDOWN_P_MSK           (4)
#define HPS_MOTOR_POWERDOWN_N_MSK           (5)
#define SAFE_STATE_P_MSK                    (0x1)
#define SAFE_STATE_P_OFF                    (0)
#define SAFE_STATE_N_MSK                    (0x2)
#define SAFE_STATE_N_OFF                    (1)

/*Instance of GPIO helper functions detailed in hps_gpio.c*/
int write_hps_gpio(unsigned int *hps_gpio_base, unsigned int gpio_output);
int read_hps_gpio(unsigned int *hps_gpio_base);
int read_hps_gpio_safe_state(unsigned int *hps_gpio_base);

/*!
 * @}
 */
