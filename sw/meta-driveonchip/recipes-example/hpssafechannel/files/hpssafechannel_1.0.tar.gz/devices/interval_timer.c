/* ##########################################################################
 * Copyright 2015 - 2024 Intel Corporation.
 *
 * This software and the related documents are Intel copyrighted materials, f
 * and your use of them is governed by the express license under which they
 * were provided to you ("License"). Unless the License provides otherwise,
 * you may not use, modify, copy, publish, distribute, disclose or transmit
 * this software or the related documents without Intel's prior written permission.
 *
 * This software and the related documents are provided as is, with no express
 * or implied warranties, other than those that are expressly stated in the License.
 * ##########################################################################
 */

#include <string.h>
#include "interval_timer.h"

/**
 * @file interval_timer.c
 *
 * @brief Driver to set the interval timer to run, manage IRQ and set the count.
 */

/**
 * @brief timer_set_freerunning().
 *
 * timer_set_freerunning() is called to initialise the timer that will be
 * used to provide the periodic system clock. Note that the following bits
 * are enabled by the function: IRQ generation, continous count, and start.
 */
void timer_set_freerunning(unsigned int *base)
{
    /* set to free running mode */

    *(base + TIMER_CONTROL_REG) = (TIMER_CONTROL_ITO_MSK |
                                   TIMER_CONTROL_CONT_MSK |
                                   TIMER_CONTROL_START_MSK);
}

/**
 * @brief set_timestamp_start ().
 *
 * The function can be called at application level to
 * initialise the timestamp facility. In this case the period register is
 * set to the value of count, the user must know the frequency of the
 * internal timer to set the interval. Note that
 * the period register may not be writable, depending on the hardware
 * configuration, in which case this function does not reset the period.
 */
int set_timestamp_start(unsigned int *base, int ms)
{
    long long count = (long long) (ms) * TIMER_CLK_FREQ_HZ / 1000;

    if (TIMESTAMP_COUNTER_SIZE == 64) {
        *(base + TIMER_CONTROL_REG) = TIMER_CONTROL_STOP_MSK;
        *(base + TIMER_PERIOD_0_REG) = (count & TIMER_PERIOD_0_MSK) >> 0;
        *(base + TIMER_PERIOD_1_REG) = (count & TIMER_PERIOD_1_MSK) >> 16;
        *(base + TIMER_PERIOD_2_REG) = (count & TIMER_PERIOD_2_MSK) >> 32;
        *(base + TIMER_PERIOD_3_REG) = (count & TIMER_PERIOD_3_MSK) >> 48;
    } else {
        *(base + TIMER_CONTROL_REG) = TIMER_CONTROL_STOP_MSK;
        *(base + TIMER_PERIODL_REG) = (count & TIMER_PERIODL_MSK) >> 0;
        *(base + TIMER_PERIODH_REG) = (count & TIMER_PERIODH_MSK) >> 16;
    }
    return 0;
}

/**
 * @brief clear_irq_timeout ().
 *
 * The function  can be called at application level to
 * remove the Internal TimeOut, hence to lower the IRQ signal.
 * The timer continues running as the continous and start bit are
 * remaining in 1
 */
int clear_irq_timeout(unsigned int *base)
{
    *(base + TIMER_CONTROL_REG) = (0 | TIMER_CONTROL_CONT_MSK | TIMER_CONTROL_START_MSK);
    return 0;
}

/**
 * @brief clear_timeout ().
 *
 * The function can be called at application level to
 * clean the TO bit in the status register. Once there uis  a timeout event
 * the TO bit stays set until explicitely cleared by a host peripheral.
 * Writteing a zero to the status register of the interval timer.
 */
int clear_timeout(unsigned int *base)
{
    *(base + TIMER_STATUS_REG) = (0 | TIMER_STATUS_RUN_MSK);
    return 0;
}

/**
 * @brief timestamp().
 *
 * The function returns the current timestamp count. In the event that
 * the timer has run full period this function return -1.
 *
 * The returned timestamp counts up from the last time the period register
 * was reset.
 */
long long timestamp(unsigned int *base)
{
#if (TIMESTAMP_COUNTER_SIZE == 64)
    *(base + AVALON_TIMER_SNAP_0) = 0;
    int snap_0 = *(base + TIMER_SNAP_0_REG) & TIMER_SNAP_0_MSK;
    int snap_1 = *(base + TIMER_SNAP_1_REG) & TIMER_SNAP_1_MSK;
    int snap_2 = *(base + TIMER_SNAP_2_REG) & TIMER_SNAP_2_MSK;
    int snap_3 = *(base + TIMER_SNAP_3_REG) & TIMER_SNAP_3_MSK;

    return (0xFFFFFFFFFFFFFFFFULL - ((snap_3 << 48) | (snap_2 << 32) | (snap_1 << 16) | (snap_0)));
#else
    *(base + TIMER_SNAPL_REG) = 0;
    int lower = *(base + TIMER_SNAPL_REG) & TIMER_SNAPL_MSK;
    int upper = *(base + TIMER_SNAPH_REG) & TIMER_SNAPH_MSK;

    return (0xFFFFFFFF - ((upper << 16) | lower));
#endif

}

/**
 * @brief stop_timer().
 *
 * The function stop_timer () can be called at application level
 * to stop the count and clean the "TO" signal.
 */
int stop_timer(unsigned int *base)
{
    *(base + TIMER_CONTROL_REG) = (TIMER_CONTROL_CONT_MSK | TIMER_CONTROL_STOP_MSK);
    clear_timeout(base);
    return 0;
}

/*!
 * @}
 */
