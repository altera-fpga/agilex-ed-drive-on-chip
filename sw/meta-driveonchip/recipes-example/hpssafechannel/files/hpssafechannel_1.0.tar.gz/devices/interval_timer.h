/* ##########################################################################
 * Copyright 2015 - 2024 Intel Corporation.
 *
 * This software and the related documents are Intel copyrighted materials,
 * and your use of them is governed by the express license under which they
 * were provided to you ("License"). Unless the License provides otherwise,
 * you may not use, modify, copy, publish, distribute, disclose or transmit
 * this software or the related documents without Intel's prior written permission.
 *
 * This software and the related documents are provided as is, with no express
 * or implied warranties, other than those that are expressly stated in the License.
 * ##########################################################################
 */

/**
 * @file interval_timer.h
 *
 * @brief Interface functions and constants for Interval Timer management
 */

// Interval Timer STATUS register
#define TIMER_STATUS_REG                    0
#define TIMER_STATUS_TO_MSK                 (0x1)
#define TIMER_STATUS_TO_OFST                (0)
#define TIMER_STATUS_RUN_MSK                (0x2)
#define TIMER_STATUS_RUN_OFST               (1)

// Interval Timer CONTROL register
#define TIMER_CONTROL_REG                   1

#define TIMER_CONTROL_ITO_MSK               (0x1)
#define TIMER_CONTROL_ITO_OFST              (0)
#define TIMER_CONTROL_CONT_MSK              (0x2)
#define TIMER_CONTROL_CONT_OFST             (1)
#define TIMER_CONTROL_START_MSK             (0x4)
#define TIMER_CONTROL_START_OFST            (2)
#define TIMER_CONTROL_STOP_MSK              (0x8)
#define TIMER_CONTROL_STOP_OFST             (3)

# define TIMESTAMP_COUNTER_SIZE             32
# define TIMER_CLK_FREQ_HZ                  100000000

// Period and SnapShot Register for COUNTER_SIZE = 32

// PERIODL register
#define TIMER_PERIODL_REG                   2
#define TIMER_PERIODL_MSK                   ((0xFFFF) << 0)
#define TIMER_PERIODL_OFST                  (0)

// PERIODH register
#define TIMER_PERIODH_REG                   3
#define TIMER_PERIODH_MSK                   ((0xFFFF) << 16)
#define ATIMER_PERIODH_OFST                 (0)

// SNAPL register
#define TIMER_SNAPL_REG                     4
#define TIMER_SNAPL_MSK                     (0xFFFF)
#define TIMER_SNAPL_OFST                    (0)

// SNAPH register
#define TIMER_SNAPH_REG                     5
#define TIMER_SNAPH_MSK                     (0xFFFF)
#define TIMER_SNAPH_OFST                    (0)

// Period and SnapShot Register for COUNTER_SIZE = 64

// PERIOD_0 register
#define TIMER_PERIOD_0_REG                  2
#define TIMER_PERIOD_0_MSK                  ((0xFFFF) << 0)
#define TIMER_PERIOD_0_OFST                 (0)

// PERIOD_1 register
#define TIMER_PERIOD_1_REG                  3
#define TIMER_PERIOD_1_MSK                  ((0xFFFF) << 16)
#define TIMER_PERIOD_1_OFST                 (0)

// PERIOD_2 register
#define TIMER_PERIOD_2_REG                  4
#define TIMER_PERIOD_2_MSK                  ((long long)(0xFFFF) << 32)
#define TIMER_PERIOD_2_OFST                 (0)

// PERIOD_3 register
#define TIMER_PERIOD_3_REG                  5
#define TIMER_PERIOD_3_MSK                  ((long long)(0xFFFF) << 48)
#define TIMER_PERIOD_3_OFST                 (0)

// SNAP_0 register
#define ATIMER_SNAP_0_REG                   6
#define TIMER_SNAP_0_MSK                    (0xFFFF)
#define TIMER_SNAP_0_OFST                   (0)

// SNAP_1 register
#define TIMER_SNAP_1_REG                    7
#define TIMER_SNAP_1_MSK                    (0xFFFF)
#define TIMER_SNAP_1_OFST                   (0)

// SNAP_2 register
#define TIMER_SNAP_2_REG                    8
#define TIMER_SNAP_2_MSK                    (0xFFFF)
#define TIMER_SNAP_2_OFST                   (0)

// SNAP_3 register
#define TIMER_SNAP_3_REG                    9
#define TIMER_SNAP_3_MSK                    (0xFFFF)
#define TIMER_SNAP_3_OFST                   (0)


/* Instance of interval timer functions detailed in interval_timer.c */
extern void timer_set_freerunning(unsigned int *base);
extern int set_timestamp_start(unsigned int *base, int ms);
extern int clear_irq_timeout(unsigned int *base);
extern int clear_timeout(unsigned int *base);
extern long long timestamp(unsigned int *base);
extern int stop_timer(unsigned int *base);

/*!
 * @}
 */
