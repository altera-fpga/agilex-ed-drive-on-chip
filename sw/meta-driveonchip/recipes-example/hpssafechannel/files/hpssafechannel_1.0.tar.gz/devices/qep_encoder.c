/* ##########################################################################
 * Copyright 2015 - 2024 Intel Corporation.
 *
 * This software and the related documents are Intel copyrighted materials, f
 * and your use of them is governed by the express license under which they
 * were provided to you ("License"). Unless the License provides otherwise,
 * you may not use, modify, copy, publish, distribute, disclose or transmit
 * this software or the related documents without Intel's prior written permission.
 *
 * This software and the related documents are provided as is, with no express
 * or implied warranties, other than those that are expressly stated in the License.
 * ##########################################################################
 */

/**
 * @file qep_encoder.c
 *
 * @brief Interface functions for the QEP encoder
 */
#include "qep_encoder.h"

/**
 * @brief get_encoder_raw_speed().
 *
 * Read the value of the encoder count from the register
 * the encoder for the HPS function is likely located in
 * the Drive-On-Chip drive_subsystem_x
 */
int get_encoder_raw_speed(unsigned int *encoder_address)
{
    return  *(encoder_address + QEP_COUNT_CAPTURE_REG);

}

/*!
 * @}
 */
