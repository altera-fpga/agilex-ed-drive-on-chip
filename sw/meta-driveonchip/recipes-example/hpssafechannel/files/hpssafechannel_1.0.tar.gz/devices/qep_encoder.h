/* ##########################################################################
 * Copyright 2015 - 2024 Intel Corporation.
 *
 * This software and the related documents are Intel copyrighted materials,
 * and your use of them is governed by the express license under which they
 * were provided to you ("License"). Unless the License provides otherwise,
 * you may not use, modify, copy, publish, distribute, disclose or transmit
 * this software or the related documents without Intel's prior written permission.
 *
 * This software and the related documents are provided as is, with no express
 * or implied warranties, other than those that are expressly stated in the License.
 * ##########################################################################
 */

/**
 * @file qep_encoder.h
 *
 * @brief Interface functions and constants for QEP encoder in the DoC
 * for HPS safety channel
 */

/*QEP register definitions*/
#define ENCODER_MAX_COUNT                   (4096*2)
#define ENC_RUNNING                         1
#define SPEED_FRAC_BITS                     4
#define SPEED_SCALE                         (60<<SPEED_FRAC_BITS)   // Scale factor for speed command which is in RPM

#define QEP_CONTROL_REG                     (0)                     // RW
#define QEP_COUNT_CAPTURE_REG               (1)                     // R
#define QEP_MAX_COUNT_REG                   (2)                     // RW
#define QEP_COUNT_REG                       (3)                     // RW
#define QEP_INDEX_CAPTURE_REG               (4)                     // R

#define QEP_CONTROL_DIRECTION_OFST          (0)
#define QEP_CONTROL_DIRECTION_MSK           (1<<QEP_CONTROL_DIRECTION_OFST)
#define QEP_DIRECTION_A_B_CW                (0)
#define QEP_DIRECTION_B_A_CCW               (1)
#define QEP_CONTROL_INDEX_RESET_OFST        (1)
#define QEP_CONTROL_INDEX_RESET_MSK         (1<<QEP_CONTROL_INDEX_RESET_OFST)
#define QEP_INDEX_RESET_ENABLE              (1)
#define QEP_INDEX_RESET_DISABLE             (0)
#define QEP_CONTROL_INDEX_CAPTURE_OFST      (2)
#define QEP_CONTROL_INDEX_CAPTURE_MSK       (1<<QEP_CONTROL_INDEX_CAPTURE_OFST)
#define QEP_CONTROL_INDEX_CAPTURE_ENABLE    (1)
#define QEP_CONTROL_INDEX_CAPTURE_DISABLE   (0)

/*Instance of interval timer functions detailed in qep_encoder.c*/
int get_encoder_raw_speed(unsigned int *encoder_address);

/*!
 * @}
 */
