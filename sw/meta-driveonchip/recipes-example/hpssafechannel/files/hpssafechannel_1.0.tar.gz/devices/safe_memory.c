/* ##########################################################################
 * Copyright 2015 - 2024 Intel Corporation.
 *
 * This software and the related documents are Intel copyrighted materials, f
 * and your use of them is governed by the express license under which they
 * were provided to you ("License"). Unless the License provides otherwise,
 * you may not use, modify, copy, publish, distribute, disclose or transmit
 * this software or the related documents without Intel's prior written permission.
 *
 * This software and the related documents are provided as is, with no express
 * or implied warranties, other than those that are expressly stated in the License.
 * ##########################################################################
 */

/**
 * @file safe_memory.c
 *
 * @brief Interface functions for DoC Safety Dump memory of Drive-On-Chip
 * (for visualization only) in the control_subsystemX
 */

#include "safe_memory.h"

/**
 * @brief write_fpgapayload ().
 *
 * Refresh the fpga payload in the Safe Memory
 */
void write_fpgapayload(unsigned int *safe_mem_address, unsigned int fpga_payload)
{
    *(safe_mem_address + FPGA_PAYLOAD_OFFSET) = fpga_payload;
}

/**
 * @brief write_fpgastatus ().
 *
 * Refresh the fpga info in the safe Memory
 */
void write_fpgastatus(unsigned int *safe_mem_address, unsigned int fpga_status)
{
    *(safe_mem_address + FPGA_STATUS_OFFSET) = fpga_status;
}

/**
 * @brief write_hpspayload ().
 *
 * Refresh the hps payload in the Safe Memory
 */
void write_hpspayload(unsigned int *safe_mem_address, unsigned int hps_payload)
{
    *(safe_mem_address + HPS_PAYLOAD_OFFSET) = hps_payload;
}

/**
 * @brief write_hpsstatus ().
 *
 * Refresh the hps info/status in the Safe Memory
 */
void write_hpsstatus(unsigned int *safe_mem_address, unsigned int hps_status)
{
    *(safe_mem_address + HPS_STATUS_OFFSET) = hps_status;
}

/**
 * @brief clear_shared_mem ().
 *
 * Clear the shared memory contents
 */
void clear_shared_mem(unsigned int *safe_mem_address)
{
    *(safe_mem_address + FPGA_PAYLOAD_OFFSET) = 0;
    *(safe_mem_address + FPGA_STATUS_OFFSET) = 0;
    *(safe_mem_address + HPS_PAYLOAD_OFFSET) = 0;
    *(safe_mem_address + HPS_STATUS_OFFSET) = 0;
}

/**
 * @brief read_fpgapayload ().
 *
 * Reads the fpga payload in the Safe Memory
 */
unsigned int read_fpgapayload(unsigned int *safe_mem_address)
{
    return  *(safe_mem_address + FPGA_PAYLOAD_OFFSET);
}

/**
 * @brief read_fpgastatus ().
 *
 * Reads the fpga status in the Safe Memory
 */
unsigned int read_fpgastatus(unsigned int *safe_mem_address)
{
    return  *(safe_mem_address + FPGA_STATUS_OFFSET);
}

/**
 * @brief read_hpspayload ().
 *
 * Reads the hpspayload in the Safe Memory
 */
unsigned int read_hpspayload(unsigned int *safe_mem_address)
{
    return  *(safe_mem_address + HPS_PAYLOAD_OFFSET);
}

/**
 * @brief read_hpsstatus ().
 *
 * Reads the hps status in the Safe Memory
 */
unsigned int read_hpsstatus(unsigned int *safe_mem_address)
{
    return  *(safe_mem_address + HPS_STATUS_OFFSET);
}

/*!
 * @}
 */
