/* ##########################################################################
 * Copyright 2015 - 2024 Intel Corporation.
 *
 * This software and the related documents are Intel copyrighted materials, f
 * and your use of them is governed by the express license under which they
 * were provided to you ("License"). Unless the License provides otherwise,
 * you may not use, modify, copy, publish, distribute, disclose or transmit
 * this software or the related documents without Intel's prior written permission.
 *
 * This software and the related documents are provided as is, with no express
 * or implied warranties, other than those that are expressly stated in the License.
 * ##########################################################################
 */

/**
 * @file safe_memory.h
 *
 * @brief Interface functions and constants for DoC Safet Dump memory
 * management for visualization on the GUI.
 */

/* Memory locations */

#define FPGA_PAYLOAD_OFFSET                 (0)
#define FPGA_STATUS_OFFSET                  (1)
#define HPS_PAYLOAD_OFFSET                  (2)
#define HPS_STATUS_OFFSET                   (3)

/*Instance of safe memory functions in safe_memory.c*/
void write_fpgapayload(unsigned int *safe_mem_address, unsigned int fpga_payload);
void write_fpgastatus(unsigned int *safe_mem_address, unsigned int fpga_status);
void write_hpspayload(unsigned int *safe_mem_address, unsigned int hps_payload);
void write_hpsstatus(unsigned int *safe_mem_address, unsigned int hps_status);
void clear_shared_mem(unsigned int *safe_mem_address);
unsigned int read_fpgapayload(unsigned int *safe_mem_address);
unsigned int read_fpgastatus(unsigned int *safe_mem_address);
unsigned int read_hpspayload(unsigned int *safe_mem_address);
unsigned int read_hpsstatus(unsigned int *safe_mem_address);

/*!
 * @}
 */
