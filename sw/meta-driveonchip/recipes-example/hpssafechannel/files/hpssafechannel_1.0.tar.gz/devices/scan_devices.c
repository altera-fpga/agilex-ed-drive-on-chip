/* ##########################################################################
 * Copyright 2015 - 2024 Intel Corporation.
 *
 * This software and the related documents are Intel copyrighted materials, f
 * and your use of them is governed by the express license under which they
 * were provided to you ("License"). Unless the License provides otherwise,
 * you may not use, modify, copy, publish, distribute, disclose or transmit
 * this software or the related documents without Intel's prior written permission.
 *
 * This software and the related documents are provided as is, with no express
 * or implied warranties, other than those that are expressly stated in the License.
 * ##########################################################################
 */

/**
 * @file scan_devices.c
 *
 * @brief To manage the available devices in the design
 */
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <time.h>
#include <signal.h>
#include <errno.h>
#include "devices/interval_timer.h"
#include <stdbool.h>
#include <dirent.h>
#define _GNU_SOURCE

/**
 * @brief get_uio_device().
 *
 * get_uio_device() is called to get the base address, offset and
 * device path from the device, given the name.
 * Look for "device_name" in /sys/class/uio
 */
const char *get_uio_device(char *device_name, long *add_offset)
{
    char sys_path[1000] = "/sys/class/uio";
    char dev[256] = "/dev/";
    char name_path[1000];                                                   // will contain the path to the name file
    char offset_path[1000];                                                 // will contain the path to the offset file
    static char device_root[256] = "/dev/";
    bool device_detected = false;

    strcpy(device_root, dev);                                                // this is to clean up the static variable

    FILE *fnameptr;                                                         // file pointer for the name (if found)
    FILE *foffsetptr;                                                       // file pointer for the offset (if found)
    DIR *directory;
    struct dirent *dir;

    directory = opendir(sys_path);

    if (directory) {                                                         // this iterates over the files and dirs
        while (((dir = readdir(directory)) != NULL) & !device_detected) {
            name_path[0] = '\0';
            offset_path[0] = '\0';
            strcat(name_path, sys_path);
            strcat(name_path, "/");
            strcat(name_path, dir->d_name);
            strcat(offset_path, name_path);
            strcat(name_path, "/maps/map0/name");                            // contains potential "name" file paths
            strcat(offset_path, "/maps/map0/offset");                        // contains potential "offset" files

            fnameptr = fopen(name_path, "r");                                //tries to open the "name", but it could not exist
            char device_name_from_file[25];

            if (fnameptr == NULL) {
                    continue;                                               //if it does not exist, continue the while loop
            } else {
                fgets(device_name_from_file, 25, fnameptr);                // gets the name of the device inside the "name" file /sys/class/uio/uioX/name
                device_name_from_file[strcspn(device_name_from_file, "\n")] = '\0'; // removes\n at the end
                //printf("Device name is: %s\n", device_name_from_file);
                fclose(fnameptr);                                           // compares the name in the file with the provided name
                //printf ("The result of comparison is %d:\n", strcmp(device_name_from_file, device_name));

                if (strcmp(device_name_from_file, device_name) == 0) {       // if the name is the same
                    device_detected = true;
                    //printf("Device detected !!!!\n");
                    strcat(device_root, dir->d_name);
                    //printf("Device detected path: %s\n", device_root);

                    foffsetptr = fopen(offset_path, "r");                    //the device is detected, look for the offset file /sys/class/uio/uioX/maps/map0/offset
                    if (foffsetptr == NULL) {
                        printf("Cannot open offset path for %s", device_name_from_file);
                        exit(1);
                    }
                    char device_offset_value[25];

                    fgets(device_offset_value, 25, foffsetptr);             //gets the offset in string
                    device_offset_value[strcspn(device_offset_value, "\n")] = '\0';

                    int number = (int)strtol(device_offset_value, NULL, 16); // converts the 0x to integer
                    *add_offset = number;                                   //returns the offset

                    closedir(directory);
                    fclose(foffsetptr);
                    return device_root;
                }
            }
        }
        printf("Device with name %s not found\n", device_name);            //no device with that name was found
        closedir(directory);
    }
    return NULL;
}

/**
 * @brief get_base_address().
 *
 * get_base_address() gets the virtual base address of the device.
 * open the device in "path"
 */
int get_base_address(char *device_name, unsigned int **base, int base_offset, const char *path, unsigned long size, long offset)
{
    int fd = open(path, O_RDWR);

    printf("Path to open %s\n", path);
    if (fd < 0) {
        perror("open");
        exit(EXIT_FAILURE);
    }
    *base = (mmap(0, size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, offset));
    if ((void *)*base == MAP_FAILED) {
        printf("Failed to map %s Registers\n", device_name);
        exit(EXIT_FAILURE);
    } else {
        printf("%s base address : %p\n", device_name, &base);
    }
    *base = *base + base_offset / 4;                                        //adds the offset from the /sys/class*/map0/offset, divided by 4
    return fd;
}

/*!
 * @}
 */
