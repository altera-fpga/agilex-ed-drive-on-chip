/* ##########################################################################
 * Copyright 2015 - 2024 Intel Corporation.
 *
 * This software and the related documents are Intel copyrighted materials, f
 * and your use of them is governed by the express license under which they
 * were provided to you ("License"). Unless the License provides otherwise,
 * you may not use, modify, copy, publish, distribute, disclose or transmit
 * this software or the related documents without Intel's prior written permission.
 *
 * This software and the related documents are provided as is, with no express
 * or implied warranties, other than those that are expressly stated in the License.
 * ##########################################################################
 */

/**
 * @file scan_devices.h
 *
 * @brief Interface functions and constants scan_devices.c
 */

/*Instance of interval timer functions detailed in scan_devices.c*/
const char *get_uio_device(char *device_name, long *add_offset);
int get_base_address(char *device_name, unsigned int **base, int base_offset, const char *path, unsigned long size, long offset);

/*!
 * @}
 */
