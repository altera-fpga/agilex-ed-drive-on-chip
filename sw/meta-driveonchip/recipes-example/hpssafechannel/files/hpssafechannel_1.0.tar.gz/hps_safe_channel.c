/* ##########################################################################
 * Copyright 2015 - 2024 Intel Corporation.
 *
 * This software and the related documents are Intel copyrighted materials,
 * and your use of them is governed by the express license under which they
 * were provided to you ("License"). Unless the License provides otherwise,
 * you may not use, modify, copy, publish, distribute, disclose or transmit
 * this software or the related documents without Intel's prior written permission.
 *
 * This software and the related documents are provided as is, with no express
 * or implied warranties, other than those that are expressly stated in the License.
 * ##########################################################################
 */

#define _GNU_SOURCE
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <time.h>
#include <signal.h>
#include <curses.h>
#include <errno.h>
#include "devices/interval_timer.h"
#include "devices/scan_devices.h"
#include "devices/drive_on_chip.h"
#include "devices/hps_gpio.h"
#include "devices/safe_memory.h"
#include "devices/fpga_speed_est.h"
#include "safety_function/doc_helper.h"
#include "safety_function/speed_estimation.h"
#include "safety_function/thread_create_helper.h"
#include "safety_function/print_safety.h"
#include "safety_function/srt.h"
#include <pthread.h>
#include <stdbool.h>
#include <dirent.h>
#include <sched.h>


/**
 * @file hps_safe_channel.c
 *
 * @brief MAIN function for the HPS safety function.
 */

#define MAP_SIZE_TIMER                      0x2F
#define MAP_SIZE_QEP                        0x40
#define MAP_SIZE_MEM                        0x2F
#define MAP_SIZE_GPIO                       0x40
#define MAP_SIZE_DOC                        0x40
#define FPGA_SE_SIZE_DOC                    0x2F
//#define INTERRUPT_FREQ_MS                   1
#define SPEED_ESTIMATION_SCHED_PRIORITY     90
#define SPEED_ESTIMATION_CORE_ALLOC         3
#define PRINT_RESULTS_SCHED_PRIORITY        70
#define PRINT_RESULTS_CORE_ALLOC            1
#define READ_KEY_SCHED_PRIORITY             65
#define READ_KEY_CORE_ALLOC                 0
#define SRT_SCHED_PRIORITY                  90
#define SRT_CORE_ALLOC                      2
#define INITIAL_SLEEP_SEC                   2
#define MAIN_CORE_ALLOC                     2

/* Pointer and structure initialization */
bool *signalTerm = NULL;
bool enable_print = true;
unsigned int *timer_base   = NULL;
unsigned int *qep_base     = NULL;
unsigned int *payload_base = NULL;
unsigned int *hps_gpio_base = NULL;
unsigned int *doc_gui_mem_base = NULL;
unsigned int *doc_debug_mem_base = NULL;
unsigned int *fpga_speed_est_base = NULL;
long base_offset = 0;

encoder_priv_struct qep_struct;
safety_results results_struct;

/* Data necessary to initialize the threads */
pthread_t   speedEstThreadID;
static int  speedEstThreadPriority  = SPEED_ESTIMATION_SCHED_PRIORITY;
static int  speedEstThreadCore      = SPEED_ESTIMATION_CORE_ALLOC;

pthread_t   printResultsThreadID;
static int  printThreadPriority     = PRINT_RESULTS_SCHED_PRIORITY;
static int  printThreadCore         = PRINT_RESULTS_CORE_ALLOC;

pthread_t   readKeyboardThreadID;
static int  readThreadPriority     = READ_KEY_SCHED_PRIORITY;
static int  readThreadCore         = READ_KEY_CORE_ALLOC;

pthread_t   SRTThreadID;
static int  SRTThreadPriority     = SRT_SCHED_PRIORITY;
static int  SRTThreadCore         = SRT_CORE_ALLOC;

/* Measurements */
#define REPETITIONS                         15000

/**
 * @brief Function to handle the stop signal.
 * Signals the threads to stop and clean pointers
 * this is triggered every ctrl+c
 */
static void handlerStop()
{
    printf("received ctrl-c\n");
    *signalTerm = true;
    printf("Value terminal %d\n", *signalTerm);
    if (enable_print) {
        endwin();               // End curses mode
    }
}


/**
 * @brief Main Funtion
 * 1. Sets up the stop handler.
 * 2. Mapping of the devices: QEP encoder, Interval Timer,
 *    payload memory and results GPIO.
 * 3. Creation of threads: for speed estimation and terminal prints.
 * 4. While task to detec interrupts (safety funtion).
 * 5. Cleaning after finish execution.
 */
int main(int argc, char *argv[])
{
     cpu_set_t cpuset;

     CPU_ZERO(&cpuset);                                                     // clear cpu mask
     CPU_SET(MAIN_CORE_ALLOC, &cpuset);                                     // set cpu MAIN_CORE_ALLOC
     if (sched_setaffinity(getpid(), sizeof(cpuset), &cpuset) == -1) {
         perror("sched_setaffinity");
         exit(EXIT_FAILURE);
     }

    /* -------------------0. Check arguments----------------------*/
    printf("\nProgram name is: %s\n", argv[0]);

    if (argc == 1)
        printf("\nNo Extra Command Line Argument Passed Other Than Program Name");

    if (argc >= 2) {
        for (int i = 0; i < argc; i++) {
            if (!strcmp(argv[1], "-help")) {
                printf("Safe Drive on Chip HPS application.\n");
                printf("Options:\n");
                printf("-no-print             Do not print status on the screen.\n");
                printf("\n");
                return 0;

            } else {
                if (!strcmp(argv[1], "-no-print")) {
                    enable_print = false;
                } else {
                    printf("Invalid argument, use './hpssafechannel -help' for valid arguments\n\n");
                    return 0;
                }
            }
        }
    }

    /* ------------------ 1. Stop handler setup ------------------*/

    signalTerm = malloc(10 * sizeof(bool));
    *signalTerm = false;
    base_offset = 0;

    signal(SIGINT, handlerStop);
    signal(SIGTERM, handlerStop);

    /* --------------------- 2. Map devices ----------------------*/

    /*Init structures for to map the pointers*/
    encoder_priv_struct *qep_ptr = &qep_struct;
    safety_results *results_ptr = &results_struct;

    init_encoder(qep_ptr);
    init_compare_struct(results_ptr);

    /* 2.1 ---- Interval Timer ----*/
    char intervalTimer0[20] = "interval_timer0";

    const char *rtnPath = get_uio_device(intervalTimer0, &base_offset);
    int fd_timer = get_base_address(intervalTimer0, &timer_base, base_offset, rtnPath, MAP_SIZE_TIMER, 0);

    /* 2.2 ------ QEP encoder -----*/
    char qepEncoder[20] = "doc_qep0";

    rtnPath = get_uio_device(qepEncoder, &base_offset);
    int fd_qep = get_base_address(qepEncoder, &qep_base, base_offset, rtnPath, MAP_SIZE_QEP, 0);

    /* 2.3 ---- Payload Memory ----*/
    char payloadMem[20] = "shared_mem0";

    rtnPath = get_uio_device(payloadMem, &base_offset);
    int fd_payload = get_base_address(payloadMem, &payload_base, base_offset, rtnPath, MAP_SIZE_MEM, 0);

    /* 2.4 -- GPIO for results ----*/
    char hpsGPIO[20] = "hps_fpga_gpio0";

    rtnPath = get_uio_device(hpsGPIO, &base_offset);
    int fd_hps_gpio = get_base_address(hpsGPIO, &hps_gpio_base, base_offset, rtnPath, MAP_SIZE_GPIO, 0);

    /* 2.5 -- GUI  memory ----*/
    char docGUIMem[20] = "doc_safety_dump0";

    rtnPath = get_uio_device(docGUIMem, &base_offset);
    int fd_gui_mem = get_base_address(docGUIMem, &doc_gui_mem_base, base_offset, rtnPath, MAP_SIZE_DOC, 0);

    /* 2.6 -- DoC Debug mem  memory ----*/
    char docDebugMem[20] = "doc_debug_ram0";

    rtnPath = get_uio_device(docDebugMem, &base_offset);
    int fd_doc_mem = get_base_address(docDebugMem, &doc_debug_mem_base, base_offset, rtnPath, MAP_SIZE_DOC, 0);

    /* 2.7 -- FPGA speed estimator ----*/
    char fpgaSpeedEst[25] = "fpga_speed_estimator0";

    rtnPath = get_uio_device(fpgaSpeedEst, &base_offset);
    int fd_fpga_est = get_base_address(fpgaSpeedEst, &fpga_speed_est_base, base_offset, rtnPath, FPGA_SE_SIZE_DOC, 0);

    printf("App State%s.\n", doc_application_states[*(doc_debug_mem_base  + DOC_DBG_APP_STATE)]);

    /* ------------------ 3. Thread creation ---------------------*/

    /* 3.1 -- Create thread for Speed Estimation ----*/
    threadArg *threadArguments  = (threadArg *) malloc(sizeof(threadArg));

    threadArguments->qep_base   = qep_base;
    threadArguments->qep_ptr    = qep_ptr;
    threadArguments->signalTerm = signalTerm;
    char threadSpeedName[22]    = "speedCalThread";

    speedEstThreadID = createThread((int) speedEstThreadPriority, (size_t)speedEstThreadCore, userAppSpeedEst, threadSpeedName, threadArguments);

    /* 3.2 -- Create thread for Terminal Prints ----*/
    if (enable_print) {
        threadArgPrint *threadArgumentsPrint  = (threadArgPrint *) malloc(sizeof(threadArgPrint));

        threadArgumentsPrint->results_struct = results_ptr;
        threadArgumentsPrint->signalTerm = signalTerm;
        threadArgumentsPrint->doc_gui_base = doc_gui_mem_base;
        threadArgumentsPrint->doc_debug_mem_base = doc_debug_mem_base;
        threadArgumentsPrint->hps_gpio_base = hps_gpio_base;
        char threadPrintName[22]    = "printResultsThread";

        printResultsThreadID = createThread((int) printThreadPriority, (size_t)printThreadCore, printingApp, threadPrintName, threadArgumentsPrint);
    }

    /* 3.3 -- Create a thread to read from keyboard --*/
    threadArgRead *threadArgumentsRead  = (threadArgRead *) malloc(sizeof(threadArgRead));

    threadArgumentsRead->signalTerm = signalTerm;
    char threadReadName[22]    = "readKeyboardThread";

    readKeyboardThreadID = createThread((int) readThreadPriority, (size_t)readThreadCore, readKeyApp, threadReadName, threadArgumentsRead);


    /* 3.4 -- Create a thread to do Safety Function --*/
    clear_over_speed_latch(fpga_speed_est_base);
    clear_shared_mem(payload_base);
    sleep(INITIAL_SLEEP_SEC);                                               //give some time to the thread to calculate

    threadArgSRT *threadArgumentsSRT  = (threadArgSRT *) malloc(sizeof(threadArgSRT));

    threadArgumentsSRT->signalTerm = signalTerm;
    threadArgumentsSRT->timer_base = timer_base;
    threadArgumentsSRT->payload_base = payload_base;
    threadArgumentsSRT->hps_gpio_base = hps_gpio_base;
    threadArgumentsSRT->doc_gui_base = doc_gui_mem_base;
    threadArgumentsSRT->doc_debug_mem_base = doc_debug_mem_base;
    threadArgumentsSRT->fpga_speed_est_base = fpga_speed_est_base;
    threadArgumentsSRT->fd_timer = fd_timer;
    threadArgumentsSRT->qep_ptr    = qep_ptr;
    threadArgumentsSRT->results_struct = results_ptr;
    char threadSRTName[22]    = "SRTThread";

    SRTThreadID = createThread((int) SRTThreadPriority, (size_t)SRTThreadCore, SRTApp, threadSRTName, threadArgumentsSRT);

    /* ----------------- 4. Wait to Finish and clean -----------------*/

    while (!(*signalTerm)) {
        usleep(1000);
    }
    *signalTerm = true;
    system("reset");
    sleep(1);                                                               //signal term to actuate in the other threads before finishing

    close(fd_timer);
    close(fd_qep);
    close(fd_payload);
    close(fd_hps_gpio);
    close(fd_gui_mem);
    close(fd_doc_mem);
    close(fd_fpga_est);
    exit(EXIT_SUCCESS);
    return 0;

}

/*!
 * @}
 */
