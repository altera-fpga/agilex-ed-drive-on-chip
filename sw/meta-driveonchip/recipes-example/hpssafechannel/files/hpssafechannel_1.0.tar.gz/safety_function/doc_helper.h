/* ##########################################################################
 * Copyright 2015 - 2024 Intel Corporation.
 *
 * This software and the related documents are Intel copyrighted materials,
 * and your use of them is governed by the express license under which they
 * were provided to you ("License"). Unless the License provides otherwise,
 * you may not use, modify, copy, publish, distribute, disclose or transmit
 * this software or the related documents without Intel's prior written permission.
 *
 * This software and the related documents are provided as is, with no express
 * or implied warranties, other than those that are expressly stated in the License.
 * ##########################################################################
 */

/**
 * @file doc_helper.h
 *
 * @brief Status and modes strings to show in the commandline
 * the information is retrieved from DoC Debug Mem and
 * displayed in command line.
 */

static const char * const doc_application_states[] = {
    "Idle - Not started",
    "Initialization",
    "Drive initialization",
    "PWM initialization",
    "Wait for DC input valid",
    "DC input valid",
    "ADC calibration",
    "ADC calibrated",
    "ADC calibration failed",
    "Initialize DCDC converter",
    "Encoder service",
    "Loopback mode",
    "In dcdc_ok loop",
    "Encoder calibration",
    "Encoder reset",
    "Encoder calibrated",
    "Encoder calibration done",
    "Drive enabled",
    "DCDC error",
    "DCDC  mode changing",
    "Drive restarting"
};

static const char * const doc_dsm_states[] = {
    "InitDSM",
    "Pre-Charge",
    "Pre-Run",
    "Running",
    "Error",
    "Startup Power Check",
    "Encoder Init",
    "Encoder Init OK"
};

static const char * const doc_dsp_modes[] = {
    "Software Fixed-Point",
    "DSPBA Fixed-Point"
};

enum demo_modes {
    DEMO_RESET                          = 0,
    DEMO_OPEN_LOOP_SINE_16              = 1,
    DEMO_OPEN_LOOP_SINE_32              = 2,
    DEMO_FOC_SENSOR_16_2                = 5,
    DEMO_FOC_SENSOR_32_2                = 6,
    DEMO_FOC_SENSOR_DSP_FIXED_64_2      = 12,
};

static const char * const doc_demo_modes[] = {
    [DEMO_RESET]                        = "Reset",
    [DEMO_OPEN_LOOP_SINE_16]            = "Open Loop Sinusoidal 16kHz V/Hz",
    [DEMO_OPEN_LOOP_SINE_32]            = "Open Loop Sinusoidal 32kHz V/Hz",
    [DEMO_FOC_SENSOR_16_2]              = "FOC Sensor 16kHz Dual Axis",
    [DEMO_FOC_SENSOR_32_2]              = "FOC Sensor 32kHz Dual Axis",
    [DEMO_FOC_SENSOR_DSP_FIXED_64_2]    = "FOC Sensor 64kHz Dual Axis"
};

/*!
 * @}
 */
