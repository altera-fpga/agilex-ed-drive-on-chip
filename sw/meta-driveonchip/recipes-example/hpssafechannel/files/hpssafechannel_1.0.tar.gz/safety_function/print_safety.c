/* ##########################################################################
 * Copyright 2015 - 2024 Intel Corporation.
 *
 * This software and the related documents are Intel copyrighted materials,
 * and your use of them is governed by the express license under which they
 * were provided to you ("License"). Unless the License provides otherwise,
 * you may not use, modify, copy, publish, distribute, disclose or transmit
 * this software or the related documents without Intel's prior written permission.
 *
 * This software and the related documents are provided as is, with no express
 * or implied warranties, other than those that are expressly stated in the License.
 * ##########################################################################
 */

/**
 * @file print_safety.c
 *
 * @brief Printing results to the Linux Terminal
 */

#define _GNU_SOURCE
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>
#include <sched.h>
#include <curses.h>
#include <fcntl.h>
#include <errno.h>
#include "print_safety.h"
#include "doc_helper.h"
#include "drive_on_chip.h"
#include "speed_estimation.h"
#include "thread_create_helper.h"
#include "hps_gpio.h"

/**
 * @brief printingApp for terminal visualization.
 *
 * The function printingApp will show in the Linux terminal
 * relevant data for the user, oriented to the payload of the
 * HPS and FPGA safety channels.
 */

void *printingApp(void *arg)
{
    safety_results *results_ptr_app;
    bool *signalTerm;
    unsigned int *doc_debug_mem_base;
    unsigned int *hps_gpio_base;

    threadArgPrint *threadArgumentsApp = (threadArgPrint *)arg;

    results_ptr_app = threadArgumentsApp->results_struct;
    signalTerm = threadArgumentsApp->signalTerm;
    doc_debug_mem_base = threadArgumentsApp->doc_debug_mem_base;
    hps_gpio_base = threadArgumentsApp->hps_gpio_base;

    initscr();			// Start curses mode
    int count = 0;
    unsigned int over_speed_hps = 0;
    unsigned int over_speed_fpga = 0;
    unsigned int safe_state = 0;

    print_background(count);

    while (!(*signalTerm)) {                                                                              //runs forever but a flag can be created to stop it
            sleep(1);

            mvprintw(10, 22, "  %d   ", ((results_ptr_app->payload_HPS >> SPEED_OFFSET) & SPEED_MASK));
            mvprintw(12, 22, "  %d   ", ((results_ptr_app->payload_FPGA >> SPEED_OFFSET) & SPEED_MASK));

            over_speed_hps = (results_ptr_app->payload_HPS >> OVER_SPEED_OFFSET) & OVER_SPEED_MASK;
            over_speed_fpga = (results_ptr_app->payload_FPGA >> OVER_SPEED_OFFSET) & OVER_SPEED_MASK;
            safe_state = (read_hps_gpio_safe_state(hps_gpio_base) & SAFE_STATE_P_MSK) >> SAFE_STATE_P_OFF;

            if (over_speed_hps == 1)
                mvprintw(10, 40, "YES");
            else
                mvprintw(10, 40, "NO ");

            if (over_speed_fpga == 1)
                mvprintw(12, 40, "YES");
            else
                mvprintw(12, 40, "NO ");

            if (!(results_ptr_app->hps_compare_good_p)) {
                mvprintw(10, 55, "FAIL");
                mvprintw(12, 55, "FAIL");
            } else {
                mvprintw(10, 55, "OK  ");
                mvprintw(12, 55, "OK  ");
            }

            // Drive On Chip status printing
            mvprintw(17, 28, "%s.", doc_application_states[*(doc_debug_mem_base + DOC_DBG_APP_STATE)]);
            mvprintw(18, 28, "%d seconds.", *(doc_debug_mem_base + DOC_DBG_RUNTIME));
            mvprintw(19, 28, "%s.", doc_dsm_states[*(doc_debug_mem_base + DOC_DBG_DRIVE_STATE)]);
            mvprintw(20, 28, "%s.", doc_demo_modes[*(doc_debug_mem_base + DOC_DBG_DEMO_MODE)]);
            mvprintw(21, 28, "%s.", doc_dsp_modes[*(doc_debug_mem_base + DOC_DBG_DSP_MODE)]);

            if (safe_state == 0) {
                mvprintw(22, 28, "%s.", "Motor is Running Normally               ");
            } else {
                mvprintw(22, 28, "%s.", "Motor is Powered Down into Safe State!!!");
            }

            mvprintw(26, 26, "%d", count);
            count++;
            refresh();          // Print it on to the real screen
            if (count % 10 == 0) {
                print_background(count);
            }
    }
    endwin();                   // End curses mode
    clear();

    free(threadArgumentsApp);
    return NULL;
}

void print_background(int count)
{
    clear();
    mvprintw(1, 11, "ALTERA AGILEX SOC FPGA DEVELOPMENT KIT");
    mvprintw(2, 14, "Safe Drive-On-Chip Design Example");
    mvprintw(4, 1, "This Design is based on Speed Monitoring");
    mvprintw(6, 6, "Press 'q' and 'enter' to finish the service");

    mvprintw(7, 1, "##############################################################");
    mvprintw(8, 1, "#   Payload   #   Speed (RPM)   #  Over Speed  #  Comparison #");
    mvprintw(9, 1, "##############################################################");
    mvprintw(10, 1, "#     HPS     #        0        #      xx      #       xx    #");
    mvprintw(11, 1, "#-------------#-----------------#--------------#-------------#");
    mvprintw(12, 1, "#    FPGA     #        0        #      xx      #       xx    #");
    mvprintw(13, 1, "##############################################################");

    mvprintw(15, 1, "#############  Drive On Chip Status Summary  #################");
    mvprintw(15, 1, "##############################################################");
    mvprintw(17, 1, "     Application State: ");
    mvprintw(18, 1, "     DoC Runtime:       ");
    mvprintw(19, 1, "     SM State:          ");
    mvprintw(20, 1, "     Mode Selection:    ");
    mvprintw(21, 1, "     DSP Mode:          ");
    mvprintw(22, 1, "     Motor Power Down:  ");
    mvprintw(24, 1, "##############################################################");

    mvprintw(26, 1, "Safety Function Runtime: %d", count);

}

void *readKeyApp(void *arg)
{
    threadArgRead *threadArgumentsApp = (threadArgRead *)arg;
    bool *signalTerm;
    int c;

    signalTerm = threadArgumentsApp->signalTerm;
    printf("Press 'q' to exit\n");
    fflush(stdout);
    while ((c = getchar()) != 'q') {
        usleep(1000);
    };
    *signalTerm = true;

    return NULL;
}

/*!
 * @}
 */
