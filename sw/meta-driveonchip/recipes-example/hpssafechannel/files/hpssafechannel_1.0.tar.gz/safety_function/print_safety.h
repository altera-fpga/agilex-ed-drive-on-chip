/* ##########################################################################
 * Copyright 2015 - 2024 Intel Corporation.
 *
 * This software and the related documents are Intel copyrighted materials,
 * and your use of them is governed by the express license under which they
 * were provided to you ("License"). Unless the License provides otherwise,
 * you may not use, modify, copy, publish, distribute, disclose or transmit
 * this software or the related documents without Intel's prior written permission.
 *
 * This software and the related documents are provided as is, with no express
 * or implied warranties, other than those that are expressly stated in the License.
 * ##########################################################################
 */

/**
 * @file print_safety.h
 *
 * @brief Functions to print into the terminal
 */

/*Instance of printing functions detailed in print_safety.c*/
void *printingApp(void *arg);
void print_background(int count);
void *readKeyApp(void *arg);

/*!
 * @}
 */
