/* ##########################################################################
 * Copyright 2015 - 2024 Intel Corporation.
 *
 * This software and the related documents are Intel copyrighted materials,
 * and your use of them is governed by the express license under which they
 * were provided to you ("License"). Unless the License provides otherwise,
 * you may not use, modify, copy, publish, distribute, disclose or transmit
 * this software or the related documents without Intel's prior written permission.
 *
 * This software and the related documents are provided as is, with no express
 * or implied warranties, other than those that are expressly stated in the License.
 * ##########################################################################
 */

/**
 * @file speed_estimation.c
 *
 * @brief Thread application and helper functions for speed estimation
 */

#define _GNU_SOURCE
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <unistd.h>
#include <sys/mman.h>
#include <time.h>
#include <pthread.h>
#include <string.h>
#include <sched.h>
#include "speed_estimation.h"
#include "thread_create_helper.h"
#include "hps_gpio.h"
#include "qep_encoder.h"
#include "doc_helper.h"
#include "drive_on_chip.h"
#include "safe_memory.h"
#include <sys/time.h>

int payload_count = 0;
long long time_out_usec = 0;
unsigned int payload_hps = 0;
unsigned int payload_fpga = 0;
static double  threadCycleInMsec =          THREAD_CYCLE_TIME_MS;

/* Measurements */
struct timeval t1;
struct timeval t2;


/**
 * @brief nsOverflowCheck fix ns overflow.
 *
 *   In case the expected nanoseconds fiel goes over the 1 s threshold
 *   the values need to be adjusted.
 */
void nsOverflowCheck(struct timespec *spectedTime)
{
    while (spectedTime->tv_nsec > (SECONDS_T0_NS - 1)) {                                    //If the expected ns is more than a second then
        spectedTime->tv_sec  += 1;                                                          //Increment seconds by 1
        spectedTime->tv_nsec -= SECONDS_T0_NS;                                              // clean out the ns portion of the expected
    }
}

/**
 * @brief userAppSpeedEst speed estimation Thread main function.
 *
 * Set the timing for the thread based on the value of threadCycleInMsec
 * then it calls the speed estimator function at that rate.
 */
void *userAppSpeedEst(void *arg)
{
    struct timespec nextWakeUpTime;
    struct timespec threadStartTime;
    unsigned int *qep_base_app;
	bool *signalTerm;
    encoder_priv_struct *qep_ptr_app;
    threadArg *threadArgumentsApp = (threadArg *)arg;

    qep_base_app = threadArgumentsApp->qep_base;
    qep_ptr_app = threadArgumentsApp->qep_ptr;
	signalTerm = threadArgumentsApp->signalTerm;

    clock_gettime(CLOCKID, &threadStartTime);                                               //need to get the current time

    threadStartTime.tv_sec  += SECONDS_SLEEP_TO_START;                                      //add some seconds into the future, this can be zero
    threadStartTime.tv_nsec  = 0;

    nextWakeUpTime.tv_sec  = threadStartTime.tv_sec;                                        //copy the value of seconds to the next start time
    nextWakeUpTime.tv_nsec = threadStartTime.tv_nsec;                                       // there could be some adjustment if needed
    nsOverflowCheck(&nextWakeUpTime);                                                       //check the ns to see if it overflowed into seconds

    while (!(*signalTerm)) {                                                                //runs forever but a flag can be created to stop it
        clock_nanosleep(CLOCKID, TIMER_ABSTIME, &nextWakeUpTime, NULL);                     //This thread wakes up until the time calculated by nextWakeUpTime
        estimate_speed_from_encoder(qep_base_app, qep_ptr_app, threadCycleInMsec);          //do the safety function

        nextWakeUpTime.tv_nsec += (__syscall_slong_t)(threadCycleInMsec * MSECONDS_TO_NS);  //recalculate the next wake up time
        nsOverflowCheck(&nextWakeUpTime);                                                   //check the ns to see if it overflowed into seconds
    }

    free(threadArgumentsApp);
    return NULL;
}

/**
 * @brief estimate_speed_from_encoder.
 *
 *  Algorithm to estimate speed in RPM from the encoder RAW data
 *  needs a sample rate and access to the encoder registers
 */
int estimate_speed_from_encoder(unsigned int *encoder_base, encoder_priv_struct *enc_ptr, double cycleTimeMs)
{
    //enc_ptr->encoder_raw = *(encoder_base + QEP_COUNT_CAPTURE_REG );
    enc_ptr->encoder_raw = get_encoder_raw_speed(encoder_base);
    //printf("Raw Speed #0x%X!\n", enc_ptr->encoder_raw);

    // Create 23 bit normalised position data, masking the data bits
    // 8388608 = 2^23(24 bits) ENCODER_MAX_COUNT = 4096*2 =2^13(14 bits)
    // (((8388608<<7)/ENCODER_MAX_COUNT)>>7) = 1024 = 2^10(11 bits)
    // By looking at data sheet for AU6805. encoder.raw is 12 bits.
    // encoder.enc_data = 23 bits.
    enc_ptr->encoder_data = (enc_ptr->encoder_raw * ((8388608<<7)/ENCODER_MAX_COUNT)>>7);

    enc_ptr->encoder_delta_phi = enc_ptr->encoder_data - enc_ptr->encoder_dataprev;

    if (enc_ptr->encoder_delta_phi > 0x3fffff) {
        enc_ptr->encoder_delta_phi -= 0x7fffff;
        //dp->encoder.turns_delta = -1;
    } else if (enc_ptr->encoder_delta_phi < -0x3fffff) {
        enc_ptr->encoder_delta_phi += 0x7fffff;
        //dp->encoder.turns_delta = +1;
    } else {
        //dp->encoder.turns_delta = 0;
    }

    enc_ptr->encoder_dataprev = enc_ptr->encoder_data;

    if (ENC_RUNNING) {
        // Position difference is 23 bits representing one turn.
        // v = (phi1 - phi0)/2^^23/(t1 - t0)
        // Result in rpm, so v = (phi1 - phi0)/2^^23/(t1 - t0)*60
        // ==>v = delta_phi*k ==> v = delta_phi*(1/8388608)*isr sample rate (kHz)*1000 * 60
        // ==>v = delta_phi*0.007153*isr sample rate
        // Actual calculation is adjusted to introduce some fractional bits
        // biggest sample rate 32 = 2^5
        // if isr sample rate = 16, encoder.speed_encoder = delta_phi* 117*16/(2^10)
        // encoder.speed_encoder =  delta_phi* 2^4/(2^10) = delta_phi/(2^6)
        // if isr sample rate = 32, encoder.speed_encoder = delta_phi/(2^5)
        enc_ptr->encoder_speed = (int)(117*enc_ptr->encoder_delta_phi*(1/cycleTimeMs))>>(14-SPEED_FRAC_BITS);

        // Speed observer
        // SpeedEst[k+1] = p*RawSpeedEstFromEdgesInTimestep[k+1] + (1-p)*SpeedEst[k]
        //
        // In theory, p=(Timestep/Filter time constant)
        // The Timestep at 16kHz is 1/16000 and the motor electrical and mechanical times constants are around 4ms from:
        // Tamagawa data sheet
        //
        // Hence we can set p=1/64 without losing any speed detail in theory, and even setting it much lower like 1/256 is
        // probably still fine if it makes the signal cleaner. When we run at higher update frequencies, p should be scaled
        // down accordingly.
        //
        // Initially set p = 1 and scale everything by 64 (2^6)

        enc_ptr->encoder_speed_avg = (1*enc_ptr->encoder_speed + (4-1)*enc_ptr->encoder_speed_avg)/4;

        enc_ptr->encoder_speed = enc_ptr->encoder_speed_avg;
    }
    //printf("Read Speed #%d!\n", enc_ptr->encoder_speed >> SPEED_FRAC_BITS);
    return enc_ptr->encoder_speed;
}

/**
 * @brief init_encoder initialize data structure.
 *   Initialize the data structure for the encoder data to zero.
 */
extern int init_encoder(encoder_priv_struct *encoder_ptr)
{
    encoder_ptr->encoder_dataprev = 0;
    encoder_ptr->encoder_speed = 0;
    encoder_ptr->encoder_speed_avg = 0;
    encoder_ptr->encoder_delta_phi = 0;
    encoder_ptr->encoder_data = 0;
    encoder_ptr->encoder_raw = 0;

    return 0;
}

/**
 * @brief gen_payload () HPS payload generation.
 *   1. Evaluates overspeed in the HPS channel
 *   2. Packs the HPS payload and writes it to the shared memory
 */
int gen_payload(unsigned int *safe_mem_base, encoder_priv_struct *enc_ptr, safety_results *results_ptr)
{
    // Calculation of overspeed
    enc_ptr->encoder_speed = abs(enc_ptr->encoder_speed);                       //only positive speeds
    if ((enc_ptr->encoder_speed >> SPEED_FRAC_BITS) > OVER_SPEED_THRESHOLD) {
        results_ptr->hps_is_safe_p         = 0;                                //if there is overspeed, raise the bits
        results_ptr->hps_motor_powerdown_p = 1;                                //if there is overspeed, powerdown the motor
    } else {
        results_ptr->hps_is_safe_p         = 1;
        results_ptr->hps_motor_powerdown_p = 0;
    }

    // Generate the payload and write
    payload_hps = ((!(results_ptr->hps_is_safe_p) & OVER_SPEED_MASK) << OVER_SPEED_OFFSET)
        + (((enc_ptr->encoder_speed >> SPEED_FRAC_BITS) & SPEED_MASK) << SPEED_OFFSET)
        + ((payload_count & PL_COUNT_MASK) << PL_COUNT_OFFSET);
    payload_hps = payload_hps & PAYLOAD_MASK;

    // Write HPS Payload into memory
    write_hpspayload(safe_mem_base, payload_hps);
#ifdef TEST_HPS_ONLY_ROUTINES
    write_fpgapayload(safe_mem_base, payload_hps);                          // this is to be removed as the second payload comes from FPGA
#endif

    // write in the mem that there is a valid data
    write_hpsstatus(safe_mem_base, HPS_DATA_VALID_FLAG);
#ifdef TEST_HPS_ONLY_ROUTINES
    write_fpgastatus(safe_mem_base, HPS_DATA_VALID_FLAG);                   // remove as this is done by FPGA
#endif

    // reset the counter as there is only # bits available defined by the PL_COUNT_MASK
    payload_count++;
    if (payload_count > PL_COUNT_MASK)
        payload_count = 0;

    return 0;
}

/**
 * @brief comp_payload () HPS vs FPGA payload comparison.
 *   1. Retrieves the FPGA payload (if valid)
 *   2. Compares the FPGA payload and HPS payload
 *   3. Sets signals of validity for the SM to continue,
 *   4. Writes HPS GPIO with the results
 *   5. Clears the status of the FPGA
 */
int comp_payload(unsigned int *safe_mem_base, unsigned int *hps_gpio_base, unsigned int *doc_gui_base, safety_results *results_ptr)
{
    unsigned int gpio_output;

    gettimeofday(&t1, NULL);                                                    //start a time out
    while ((read_fpgastatus(safe_mem_base) & 0x1) != FPGA_DATA_VALID_FLAG) {
        usleep(10);
        gettimeofday(&t2, NULL);                                                //get a sample every 10us
        time_out_usec = (t2.tv_sec*USEC + t2.tv_usec) - (t1.tv_sec*USEC + t1.tv_usec);
        if (time_out_usec > MAX_TIME_OUT_USEC) {
            //printf("FPGA INVALID data: 0x%x\n", read_fpgastatus(safe_mem_base));
            // if the time-out happens the comparison is unsuccessful, so forcing the bits for the ESL and powering down the motor
            gpio_output = 
                (1 << HPS_MOTOR_POWERDOWN_P_MSK)                  | (0 << HPS_MOTOR_POWERDOWN_N_MSK) |
                (results_ptr->hps_is_safe_p << HPS_IS_SAFE_P_MSK) | (!results_ptr->hps_is_safe_p << HPS_IS_SAFE_N_MSK) |
                (0 << HPS_COMP_GOOD_P_MSK)                        | (1 << HPS_COMP_GOOD_N_MSK);
            write_hps_gpio(hps_gpio_base, gpio_output);
            return 1;
        }
    }                                                                           // need to review what happens, might be a timeout?

    //Compare the results
    payload_fpga = read_fpgapayload(safe_mem_base);                             //the address of the FPGA memory location should be used here
    payload_hps = read_hpspayload(safe_mem_base);

    int count_fpga = (payload_fpga  >> PL_COUNT_OFFSET) & PL_COUNT_MASK;
    int count_hps = (payload_hps  >> PL_COUNT_OFFSET) & PL_COUNT_MASK;
    int count_diff = abs(count_fpga - count_hps);

    int speed_fpga = (payload_fpga >> SPEED_OFFSET) & SPEED_MASK;
    int speed_hps = (payload_hps >> SPEED_OFFSET) & SPEED_MASK;
    int speed_diff = abs(speed_fpga - speed_hps);

    if ((speed_diff > MAX_SPEED_DIFF) | (count_diff != 0)) {                      // Diff in speed and count
        results_ptr->hps_compare_good_p    = 0;
        results_ptr->hps_motor_powerdown_p = 1;
    } else {
        results_ptr->hps_compare_good_p    = 1;                                    //if the comparison is negative, raise the bit
        results_ptr->hps_motor_powerdown_p = 0;                                    //if the comparison is negative, raise the bit
    }

    //Update status, comparison is done, data is valid
    // write in the mem that there is a valid data
    write_hpsstatus(safe_mem_base, HPS_COMP_DONE_FLAG);
#ifdef TEST_HPS_ONLY_ROUTINES
    write_fpgastatus(safe_mem_base, HPS_COMP_DONE_FLAG);                        // remove as this is done by FPGA
#endif

    //write the results to the HPS General IO.
    gpio_output = 
        (results_ptr->hps_motor_powerdown_p  << HPS_MOTOR_POWERDOWN_P_MSK) | (!results_ptr->hps_motor_powerdown_p  << HPS_MOTOR_POWERDOWN_N_MSK) |
        (results_ptr->hps_is_safe_p          << HPS_IS_SAFE_P_MSK)         | (!results_ptr->hps_is_safe_p          << HPS_IS_SAFE_N_MSK)         |
        (results_ptr->hps_compare_good_p     << HPS_COMP_GOOD_P_MSK)       | (!results_ptr->hps_compare_good_p     << HPS_COMP_GOOD_N_MSK);
    write_hps_gpio(hps_gpio_base, gpio_output);

    gettimeofday(&t1, NULL);                                                    //start a time out
    while (read_fpgastatus(safe_mem_base) != HPS_COMP_DONE_FLAG) {
        usleep(10);
        gettimeofday(&t2, NULL);                                                //get a sample every 10us
        time_out_usec = (t2.tv_sec*USEC + t2.tv_usec) - (t1.tv_sec*USEC + t1.tv_usec);
        if (time_out_usec > MAX_TIME_OUT_USEC) {
            //printf("FPGA INVALID data: 0x%x\n", read_fpgastatus(safe_mem_base));
            gpio_output = 
                (1 << HPS_MOTOR_POWERDOWN_P_MSK)                  | (0 << HPS_MOTOR_POWERDOWN_N_MSK) |
                (results_ptr->hps_is_safe_p << HPS_IS_SAFE_P_MSK) | (!results_ptr->hps_is_safe_p << HPS_IS_SAFE_N_MSK) |
                (0 << HPS_COMP_GOOD_P_MSK)                        | (1 << HPS_COMP_GOOD_N_MSK);
            return 1;
        }
    }

    //clear the status of the FPGA
#ifdef TEST_HPS_ONLY_ROUTINES
    write_hpsstatus(safe_mem_base, FPGA_CLEAR_STATUS_FLAG);                   // remove as this is done by FPGA
#endif
    write_fpgastatus(safe_mem_base, FPGA_CLEAR_STATUS_FLAG);

    // printf("Payload HPS:  %08X\n",payload_hps);
    // printf("Payload FPGA: %08X\n",payload_fpga);
    // printf("Payload HPS:  %08X\n",*(safe_mem_base + HPS_PAYLOAD_OFFSET));
    // printf("Payload FPGA: %08X\n",*(safe_mem_base + FPGA_PAYLOAD_OFFSET));

    results_ptr->payload_FPGA = payload_fpga;
    results_ptr->payload_HPS = payload_hps;

    //Write the Payloads back to the DoC Debug Memory for visualization in the GUI
    int motor_power_down_p = (read_hps_gpio_safe_state(hps_gpio_base) & SAFE_STATE_P_MSK) >> SAFE_STATE_P_OFF;

    safe_gui_write_fpgapayload(doc_gui_base, payload_fpga);
    safe_gui_write_fpgainfo(doc_gui_base, results_ptr->hps_compare_good_p);
    safe_gui_write_hpspayload(doc_gui_base, payload_hps);
    safe_gui_write_hpsinfo(doc_gui_base, results_ptr->hps_compare_good_p);
    safe_gui_write_safestate(doc_gui_base, motor_power_down_p);

    return 0;
}

/**
 * @brief init_compare_struct init results structure.
 *
 * Initialization of results structure to zero
 */
extern int init_compare_struct(safety_results *comp_ptr)
{
    comp_ptr->hps_motor_powerdown_p  = 1;
    comp_ptr->hps_is_safe_p          = 1;
    comp_ptr->hps_compare_good_p     = 1;

    return 0;
}

/**
 * @brief reset_payload_count
 *
 * Initialization payload count
 */

extern void reset_payload_count(void)
{
    payload_count = 0;
}

/*!
 * @}
 */
