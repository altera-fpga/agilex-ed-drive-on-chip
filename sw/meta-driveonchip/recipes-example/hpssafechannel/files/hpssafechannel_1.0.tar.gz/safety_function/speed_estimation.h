/* ##########################################################################
 * Copyright 2015 - 2024 Intel Corporation.
 *
 * This software and the related documents are Intel copyrighted materials,
 * and your use of them is governed by the express license under which they
 * were provided to you ("License"). Unless the License provides otherwise,
 * you may not use, modify, copy, publish, distribute, disclose or transmit
 * this software or the related documents without Intel's prior written permission.
 *
 * This software and the related documents are provided as is, with no express
 * or implied warranties, other than those that are expressly stated in the License.
 * ##########################################################################
 */

/**
 * @file speed_estimation.h
 *
 * @brief Constants, functions and structures to
 * calculate the speed from the QEP encoder
 */

#include <stdbool.h>
#include <time.h>

//#define TEST_HPS_ONLY_ROUTINES

/*Payload building constants*/
#define OVER_SPEED_THRESHOLD                1500
#define MAX_SPEED_DIFF                      130

#define	PAYLOAD_MASK                        0xFFFFFFFF
#define	OVER_SPEED_MASK                     0x1
#define	SPEED_MASK                          0x1FFFFFF
#define	PL_COUNT_MASK                       0x3F
#define OVER_SPEED_OFFSET                   0
#define SPEED_OFFSET                        1
#define PL_COUNT_OFFSET                     (25 + 1)

#define HPS_DATA_VALID_FLAG                 0x1
#define FPGA_DATA_VALID_FLAG                0x1
#define HPS_COMP_DONE_FLAG                  0x3
#define FPGA_CLEAR_STATUS_FLAG              0x0

/*Speed estimation thread time parameters*/
#define THREAD_CYCLE_TIME_MS                0.25
#define CLOCKID                             CLOCK_TAI
#define MSECONDS_TO_NS                      (1000 * 1000)
#define SECONDS_SLEEP_TO_START              1

#define USEC                                (1000 * 1000)
#define MAX_TIME_OUT_USEC                   (1100)

/**
 * @brief Data structure to hold private encoder parameters
 */
typedef struct {
    int             encoder_dataprev;
    int             encoder_speed;
    int             encoder_speed_avg;
    int             encoder_delta_phi;
    int             encoder_data;
    int             encoder_raw;
} encoder_priv_struct;

/**
 * @brief Data structure to hold results from safety function
 */
typedef struct {
    bool            hps_is_safe_p;
    bool            hps_compare_good_p;
    bool            hps_motor_powerdown_p;
    unsigned int    payload_HPS;
    unsigned int    payload_FPGA;
} safety_results;

/**
 * @brief structure to give parameters to the thread, pointers to QEP info
 */
typedef struct {
    safety_results  *results_struct;
    unsigned int    *doc_gui_base;
    unsigned int    *doc_debug_mem_base;
    unsigned int    *hps_gpio_base;
    bool            *signalTerm;
} threadArgPrint;

/**
 * @brief structure to give parameters to the thread, for reading a key
 */
typedef struct {
    bool            *signalTerm;
} threadArgRead;

/**
 * @brief structure to give parameters to the thread, for main SRT function
 */
typedef struct {
    bool            *signalTerm;
    unsigned int    *timer_base;
    unsigned int    *payload_base;
    unsigned int    *hps_gpio_base;
    unsigned int    *doc_gui_base;
    unsigned int    *doc_debug_mem_base;
    unsigned int    *fpga_speed_est_base;
    int             fd_timer;
    encoder_priv_struct *qep_ptr;
    safety_results  *results_struct;
} threadArgSRT;

/**
 * @brief structure to give parameters to the thread, pointers to QEP info
 */
typedef struct {
    unsigned int    *qep_base;
    encoder_priv_struct *qep_ptr;
    bool            *signalTerm;
} threadArg;

/*Instance of speed estimation functions detailed in print_safety.c*/
void nsOverflowCheck(struct timespec *timeSpecValue);
extern int estimate_speed_from_encoder(unsigned int *encoder_base, encoder_priv_struct *enc_ptr, double cycleTimeMs);
extern int init_encoder(encoder_priv_struct *encoder_ptr);
extern int gen_payload(unsigned int *safe_mem_base,  encoder_priv_struct *enc_ptr, safety_results *results);
extern int comp_payload(unsigned int *safe_mem_base, unsigned int *hps_gpio_base, unsigned int *doc_gui_base, safety_results *results);
extern int init_compare_struct(safety_results *comp_ptr);
void *userAppSpeedEst(void *arg);
extern void reset_payload_count(void);

/*!
 * @}
 */
