/* ##########################################################################
 * Copyright 2015 - 2024 Intel Corporation.
 *
 * This software and the related documents are Intel copyrighted materials,
 * and your use of them is governed by the express license under which they
 * were provided to you ("License"). Unless the License provides otherwise,
 * you may not use, modify, copy, publish, distribute, disclose or transmit
 * this software or the related documents without Intel's prior written permission.
 *
 * This software and the related documents are provided as is, with no express
 * or implied warranties, other than those that are expressly stated in the License.
 * ##########################################################################
 */

/**
 * @file srt.c
 *
 * @brief Thread application for performing main safety function
 * based on speed estimation and timer interrupt (SRT)
 */

#include "speed_estimation.h"
#include "interval_timer.h"
#include "hps_gpio.h"
#include "drive_on_chip.h"
#include "safe_memory.h"
#include "fpga_speed_est.h"
#include "doc_helper.h"
#include "srt.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>


#define INTERRUPT_FREQ_MS                   1
#define INITIAL_SLEEP_SEC_SRT               2

/**
 * @brief SRTApp safety function for HPS.
 *
 * Waits for the interrupt of the timer (SRT) and generates,
 * compares the payload for the HPS Safety Function.
 */

void *SRTApp(void *arg)
{
    threadArgSRT *threadArgumentsApp = (threadArgSRT *)arg;
    bool *signalTerm;
    unsigned int *timer_base;
    unsigned int *payload_base;
    unsigned int *hps_gpio_base;
    unsigned int *doc_gui_mem_base;
    unsigned int *doc_debug_mem_base;
    unsigned int *fpga_speed_est_base;
    int fd_timer;
    encoder_priv_struct *qep_ptr;
    safety_results *results_ptr;

    signalTerm = threadArgumentsApp->signalTerm;
    timer_base = threadArgumentsApp->timer_base;
    payload_base = threadArgumentsApp->payload_base;
    hps_gpio_base = threadArgumentsApp->hps_gpio_base;
    doc_gui_mem_base = threadArgumentsApp->doc_gui_base;
    doc_debug_mem_base = threadArgumentsApp->doc_debug_mem_base;
    fpga_speed_est_base = threadArgumentsApp->fpga_speed_est_base;
    fd_timer = threadArgumentsApp->fd_timer;
    qep_ptr = threadArgumentsApp->qep_ptr;
    results_ptr = threadArgumentsApp->results_struct;

    set_timestamp_start(timer_base, INTERRUPT_FREQ_MS);
    timer_set_freerunning(timer_base);

    int repetitions = 0;
    int time_out = 0;
    unsigned int safe_state = 0;

    while (!(*signalTerm)) {                                                // Infinite loop
        uint32_t info = 1;
        ssize_t nb = write(fd_timer, &info, sizeof(info));

        if (nb != (ssize_t)sizeof(info)) {
            perror("write");
            close(fd_timer);
            exit(EXIT_FAILURE);
        }

        nb = read(fd_timer, &info, sizeof(info));                           // the code waits for the interrupt
        if (nb == (ssize_t)sizeof(info)) {

            clear_irq_timeout(timer_base);                                 // code to respond to the interrupt
            clear_timeout(timer_base);
            timer_set_freerunning(timer_base);

        }
        repetitions++;

        gen_payload(payload_base, qep_ptr, results_ptr);
        time_out = comp_payload(payload_base, hps_gpio_base, doc_gui_mem_base, results_ptr);
        //if (time_out) {
        //    *signalTerm = true;
        //}
        safe_state = (read_hps_gpio_safe_state(hps_gpio_base) & SAFE_STATE_P_MSK) >> SAFE_STATE_P_OFF;
        if (safe_state | time_out) {
             stop_timer(timer_base);
             reset_payload_count();
             set_doc_speed(doc_debug_mem_base, 0);                          // set the speed request to 0
             //printf("Entered the safe state, press reset.\n");
             while (safe_state & !(*signalTerm)) {
                usleep(10);
                safe_state = (read_hps_gpio_safe_state(hps_gpio_base) & SAFE_STATE_P_MSK) >> SAFE_STATE_P_OFF;
                set_doc_speed(doc_debug_mem_base, 0);                       // keep the speed request at 0
                }

            clear_shared_mem(payload_base);
            int prev_demo_mode = get_demo_mode(doc_debug_mem_base);

            change_demo_mode(doc_debug_mem_base, DEMO_RESET);
            sleep(INITIAL_SLEEP_SEC_SRT);                                   //give some time to the thread to calculate
            change_demo_mode(doc_debug_mem_base, prev_demo_mode);
            set_doc_speed(doc_debug_mem_base, 100);                         // set the speed to 100RPM
            sleep(INITIAL_SLEEP_SEC_SRT);                                   //give some time to the thread to calculate
            clear_over_speed_latch(fpga_speed_est_base);
            set_timestamp_start(timer_base, INTERRUPT_FREQ_MS);
            timer_set_freerunning(timer_base);
        }
    }
    stop_timer(timer_base);
    *signalTerm = true;
    return NULL;
}

/*!
 * @}
 */
