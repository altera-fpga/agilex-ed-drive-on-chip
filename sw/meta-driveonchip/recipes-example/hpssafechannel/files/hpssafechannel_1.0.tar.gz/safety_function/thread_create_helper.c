/* ##########################################################################
 * Copyright 2015 - 2024 Intel Corporation.
 *
 * This software and the related documents are Intel copyrighted materials
 * and your use of them is governed by the express license under which they
 * were provided to you ("License"). Unless the License provides otherwise,
 * you may not use, modify, copy, publish, distribute, disclose or transmit
 * this software or the related documents without Intel's prior written permission.
 *
 * This software and the related documents are provided as is, with no express
 * or implied warranties, other than those that are expressly stated in the License.
 * ##########################################################################
 */

/**
 * @file thread_create_helper.c
 *
 * @brief Function to create threads with core affinity and
 * allocation. Including arguments.
 */

#define _GNU_SOURCE
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>
#include <sched.h>
#include "thread_create_helper.h"

/**
 * @brief createThread
 * Can be used as a template for thread creation
 * int priority: up to 98 - 99
 * size_t affinity: core allocation
 * void *(*thread)(void *) : describes the function of the thread
 * char *userAppName : name of the thread for printing
 * void *arguments: arguments to be passed to the th
 */
pthread_t createThread(int priority, size_t affinity, void *(*thread)(void *), char *userAppName, void *arguments)
{
    cpu_set_t           cpu;                                                                // Variables to set core affinity
    pthread_t           threadIdentifier;
    struct sched_param  schedulerParams;

    int setParamsReturn  = 0;
    int errorAffinity    = 0;

    threadIdentifier = pthread_self();                                                      // Contains the ID for the thread
    schedulerParams.sched_priority = priority;
    setParamsReturn = pthread_setschedparam(threadIdentifier, SCHED_FIFO, &schedulerParams);

    if (setParamsReturn != 0) {
        printf("Could not create Schedule Parameters: pthread_setschedparam\n");
        exit(1);
    }

    printf("sucessfull pthread_setschedparam:%s priority is %d\n", userAppName, schedulerParams.sched_priority);

    CPU_ZERO(&cpu);
    CPU_SET(affinity, &cpu);
    errorAffinity = pthread_setaffinity_np(threadIdentifier, sizeof(cpu_set_t), &cpu);
    if (errorAffinity) {
        fprintf(stderr, "pthread_setaffinity_np function failed: %s\n", strerror(errorAffinity));
        exit(1);
    }

    setParamsReturn = pthread_create(&threadIdentifier, NULL, thread, arguments);           //note here the argument passed to the thread
    if (setParamsReturn != 0)
        printf("Creation of the thread failed: pthread_create\n");

    if (CPU_ISSET(affinity, &cpu))
        printf("Using CPU CORE: %lu\n", (unsigned long)affinity);

   return threadIdentifier;
}

/*!
 * @}
 */
